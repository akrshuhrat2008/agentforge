# Agent Forge — Build. Break. Repair. Verify.

**Two-person Hackathon MVP · University of Debrecen · Live Telegram Bot edition (v6)**

Agent Forge turns an idea into one purpose-built AI agent, using a four-role pipeline: **Communicator → Architect → Tech Builder → Tester**. The human approves a specification before building. The tester executes five functional/adversarial cases against the actual target agent, records evidence and allows up to two evidence-driven repairs. In offline mode it clearly labels test outputs as simulated.

This version keeps the **Automation Control Center removed** and adds what was missing in v5: **real Telegram messages and automatic private-chat replies** after verification and QA. A local Telegram listener runs with FastAPI, routing messages to the approved agent or to the live Open-Meteo weather API. No WhatsApp, background scheduled weather push, or bulky automation dashboard.

## Run locally

Python 3.10+ recommended. From the extracted `agent-factory` directory:

```bash
python3 -m pip install -r requirements.txt
cp .env.example .env
# Open .env and set GEMINI_API_KEY, TELEGRAM_BOT_TOKEN and TELEGRAM_BOT_USERNAME
python3 -m uvicorn backend.main:app --host 127.0.0.1 --port 8000 --reload
```

Open **http://127.0.0.1:8000**. FastAPI serves the bundled frontend; no separate web server is required. `GET /health` checks server status without using model tokens; `GET /health/models` checks a real Gemini request.

If upgrading on your Mac: preserve your existing `.env` and `.data/projects.sqlite` **privately on your computer** and copy them into this new folder. Do not upload your keys, database or `venv` to GitHub. Existing READY projects and previously verified Telegram recipients continue working. Use `pip install -r requirements.txt` again, then restart Uvicorn.

## Telegram verification using @username

1. Create a private Telegram bot via [@BotFather](https://t.me/BotFather) and add its token and username to `.env`:

   ```dotenv
   GEMINI_API_KEY=your_gemini_key
   TELEGRAM_BOT_TOKEN=your_bot_token
   TELEGRAM_BOT_USERNAME=your_bot_username
   ```

2. **Open your own bot on Telegram and send `/start`.** Do this within one hour before requesting the code. The account must have a public `@username` set in Telegram's profile settings.
3. Open Agent Forge and click **New project**. Enter your `@username` (e.g. `@exampleuser`). No numeric Telegram ID is requested.
4. Agent Forge reads the bot's recent `/start` updates via Telegram's `getUpdates` API, matches the username to the private chat ID Telegram supplies, then sends a **random six-digit verification code** to that chat. Telegram cannot deliver a private message addressed only to an @username.
5. Enter the code on the website to unlock the four-agent workshop. Codes expire after ten minutes, allow five attempts and enforce a 60-second resend cooldown and three sends/hour limits per project and recipient.

### Telegram troubleshooting

- **No `/start` found for username:** Send `/start` again to **the same bot configured in `.env`**, then retry the website. Check the exact spelling of your account's @username.
- **Telegram webhook/listener conflict (409):** The bot can have only one `getUpdates` consumer, and `getUpdates` cannot coexist with an active webhook. Stop any second bot process and disable an existing webhook yourself. Agent Forge does not change other integrations automatically. Run one FastAPI worker, not `--workers 2` or higher.
- **Telegram cannot send code:** Ensure the account opened the bot and hasn't blocked it; check bot token and network.
- **Code invalid after restarting the server:** Request a new code. Verified accounts persist in the SQLite project database.

This is **Telegram recipient proof of possession**, not a general website login service. Do not expose this local MVP publicly; it lacks multi-user login, session authorization, CSRF protection, general API rate limiting and public-production security controls.

## Actually send and receive Telegram messages

After a verified project reaches **READY**, the Agent Sandbox shows a compact Telegram bot panel:

1. Click **Send test to Telegram**. A real `sendMessage` goes to the verified private chat (not the Agent Sandbox). You should immediately receive a message saying the agent is connected.
2. In Telegram, send `weather` or `/weather`. The backend calls **Open-Meteo** and replies with current conditions for **Debrecen**. Try `/weather Budapest` to specify a city. These readings are returned by the API, not invented by Gemini.
3. Send `hello` or another question to invoke your **READY agent**, using Gemini when configured. Its real reply will arrive in the same Telegram chat.
4. Send `/pause` to stop automatic replies and `/resume` to reactivate them; `/status` reports whether replies are on. The site has a **Pause replies / Resume replies** button as well. The enabled setting survives a restart.

**Important:** Keep `uvicorn` running on your Mac. Your Mac is the bot server; closing the terminal or letting the computer sleep stops live replies. Verification messages from v5 do not mean an agent has been deployed. The bot serves the **most recently verified READY project** for each private Telegram chat. It ignores users who have not verified their chat. It is not a production-grade bot: there is no durable delivery queue, multi-user authentication, hosting, or scheduled daily weather messages.

If Telegram test delivery works but messages do not get replies, open `http://127.0.0.1:8000/health/telegram`: `running` should be `true` and `error` should be `null`. A non-null `error` explains a conflicting webhook, token problem, or connection failure. If weather works but ordinary questions do not, your Gemini API or model may be unavailable.

## Gemini 503 errors and model configuration

If the message endpoint returns `502` with Gemini `503`, Google reported the model was **temporarily overloaded**. Your local backend and API key can be working correctly while the remote model cannot serve a request. The backend retries temporary errors and automatically tries a second model if the first remains unavailable. The failed idea remains in the text field, with a persistent explanation underneath so you can try again.

Models currently configured by default (override individually in `.env`):

| Task | Primary | Fallback |
|---|---|---|
| Architect + Tester | `gemini-3.8-flash` | `gemini-3.6-flash` |
| Builder + generated-agent chat | `gemini-3.5-flash-lite` | `gemini-3.8-flash` |

If your existing `.env` explicitly sets `MODEL_SMART=gemini-4-hydrogen`, remove that line or set `MODEL_SMART=gemini-3.8-flash`. **Do not share your API key or bot token when sending error screenshots.** Model access and quota still depend on the Google account and region; no real Google API calls are made by the offline tests.

## Build and demonstration flow

1. **Verify Telegram:** Send `/start` to your bot, enter your @username in Agent Forge and confirm the six-digit code.
2. **Communicator:** Describe your agent's users, job and an example. For instance: *“Build an assistant for international students in Debrecen that drafts checklists and never invents official university deadlines.”*
3. **Architect:** Review the generated spec and five test cases (two functional + three adversarial). Request edits or explicitly approve the current version.
4. **Builder + Tester:** Run the pipeline. It executes test cases, grades outputs, records failures and may repair the working spec up to two times while keeping the approved spec and original tests unchanged.
5. **Sandbox + Telegram:** Chat with a READY agent, send a real Telegram test message, and try `/weather`, `hello`, `/pause`, `/resume` in Telegram. Export the configuration, test evidence, history and limitations.

**Scope limitation:** This release has a real *locally hosted* Telegram listener, not a cloud deployment. There are no scheduled notifications, WhatsApp replies, unattended operation when your Mac is off, or public production security controls.

The included safe tools (`knowledge_lookup`, `calculator`, `current_time`, `task_planner`, `check_university_notices`, `draft_document_checklist`, `log_student_request`) are bounded utilities. University notices are **sample offline data**; this app does not submit university requests, reserve appointments, or independently verify deadlines.

## API routes

| Endpoint | Purpose |
|---|---|
| `POST /api/projects` | Create a project (unverified by default) |
| `POST /projects/{id}/telegram/request-code` | Body `{"username":"@exampleuser"}` |
| `POST /projects/{id}/telegram/verify` | Body `{"code":"123456"}` |
| `GET /projects/{id}/telegram/status` | Telegram verification + reply enablement + listener status |
| `POST /projects/{id}/telegram/test` | Send a **real** test message to the verified chat after QA |
| `POST /projects/{id}/telegram/control` | Body `{"enabled": false}` to pause or `true` to resume |
| `POST /projects/{id}/message` | Draft or revise the specification (verified only) |
| `POST /projects/{id}/approve` | Human approval of a specific spec version |
| `POST /projects/{id}/run-pipeline` | Start QA build, asynchronous by default |
| `GET /projects/{id}/state` | Current stage and evidence |
| `POST /projects/{id}/agent/chat` | Sandbox chat after QA pass |
| `GET /projects/{id}/export` | Export approved configuration and evidence |
| `GET /api/weather?city=Debrecen` | Current Open-Meteo weather (read-only) |
| `GET /health/models` | Live Gemini connectivity check |
| `GET /health/telegram` | Local Telegram polling loop and error status |

FastAPI API reference: http://127.0.0.1:8000/docs. All previous `/automation` routes were deliberately removed.

## Tests

```bash
python3 -m unittest discover -s tests -v
python3 scripts/build_frontend.py  # rebuilds standalone frontend/index.html
```

The tests use mocked Telegram, weather and Gemini services; they validate security gates, username resolution, live routing, pause/resume persistence, model fallback, QA and repair without revealing or spending real API credentials. Real Telegram delivery must be verified with your own bot and Telegram account on your Mac.
