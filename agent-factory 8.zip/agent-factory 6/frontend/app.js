(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  let state = null;
  let config = { mode: 'demo' };
  let pending = false;
  let pollTimer = null;
  let toastTimer = null;
  let telegramStatus = null;
  let telegramProjectId = null;
  let telegramBusy = false;

  async function api(path, opts = {}) {
    const response = await fetch(path, {
      method: opts.method || 'GET',
      headers: opts.body ? {'Content-Type':'application/json'} : {},
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    let data;
    try { data = await response.json(); } catch { data = {}; }
    if (!response.ok) throw new Error(typeof data.detail === 'string' ? data.detail : `Request failed (${response.status})`);
    return data;
  }

  function toast(message, isError = false) {
    const target = $('toast');
    target.textContent = message;
    target.classList.toggle('error', isError);
    target.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => target.classList.remove('show'), 4400);
  }

  async function action(fn) {
    if (pending) return;
    pending = true;
    $('send-requirement').disabled = true;
    $('approve-spec').disabled = true;
    $('start-pipeline').disabled = true;
    try { await fn(); }
    catch (error) { toast(error.message || 'Something went wrong.', true); }
    finally {
      pending = false;
      $('send-requirement').disabled = false;
      $('approve-spec').disabled = false;
      $('start-pipeline').disabled = false;
      if (state) render(state);
    }
  }

  function badge(element, text) { $(element).textContent = text; }

  function messageHtml(item, label) {
    const user = item.role === 'user';
    return `<div class="message ${user ? 'user' : 'assistant'}"><span class="message-avatar">${user ? 'U' : '✦'}</span><div class="bubble"><span class="message-label">${user ? 'YOU' : label}</span>${esc(item.content)}</div></div>`;
  }

  function renderSpec(spec, version) {
    if (!spec) return '';
    const group = (name, values) => `<div class="spec-section"><strong>${esc(name)}</strong><ul>${(values || []).map(s => `<li>${esc(s)}</li>`).join('')}</ul></div>`;
    const cases = (spec.test_cases || []).map(t => `${t.id} · ${t.name} (${t.kind}): ${t.expected_behavior}`);
    return `<div class="spec-card"><div class="spec-card-top"><h3>${esc(spec.name)}</h3><span class="version-chip">TZ v${version}</span></div><p class="mission">${esc(spec.mission)}</p><div class="spec-section"><strong>Role · tone · audience</strong><div class="mission">${esc(spec.role)} · ${esc(spec.tone)} · ${esc(spec.audience)}</div></div>${group('Core capabilities',spec.capabilities)}<details><summary>Review all five test cases</summary>${group('2 functional + 3 adversarial', cases)}</details><details><summary>Review rules, criteria and tools</summary>${group('Behavioral rules',spec.rules)}${group('Acceptance criteria',spec.acceptance_criteria)}${group('Enabled tools',spec.tools)}</details></div>`;
  }

  function renderMessages(current) {
    const messages = [{role:'assistant',content:'Welcome to Agent Forge! ✨\n\nDescribe the AI agent you want to create. Include its users, main job, and an example task — I will turn that into a specification for your approval.'}, ...(current.conversation || [])];
    const target = $('communicator-messages');
    const stayDown = target.scrollTop + target.clientHeight + 100 >= target.scrollHeight;
    target.innerHTML = messages.map(m => messageHtml(m, 'COMMUNICATOR')).join('');
    if (stayDown) target.scrollTop = target.scrollHeight;
    const isApproval = current.stage === 'AWAITING_SPEC_APPROVAL';
    const interviewing = current.stage === 'INTERVIEWING';
    $('spec-container').innerHTML = isApproval || current.approved_spec ? renderSpec(isApproval ? current.draft_spec : current.approved_spec, current.spec_version) : '';
    $('requirement-composer').hidden = !(interviewing || isApproval);
    $('approval-actions').hidden = !isApproval;
    $('requirement-text').placeholder = isApproval ? 'Tell the Architect exactly what to change…' : 'e.g. Build an agent that helps students manage…';
    $('input-hint').textContent = isApproval ? 'Feedback creates a new spec version.' : 'Your use case becomes the blueprint.';
    $('send-requirement').innerHTML = isApproval ? 'Request edit <span>↗</span>' : 'Draft spec <span>↗</span>';
    badge('communicator-badge', isApproval ? 'REVIEW' : interviewing ? 'DISCOVERY' : 'COMPLETE');
  }

  function renderRail(current) {
    const nodes = ['communicator','architect','builder','tester'];
    const stage = current.stage;
    const statuses = {
      INTERVIEWING: ['active','','',''],
      AWAITING_SPEC_APPROVAL: ['done','active','',''],
      BUILDING: ['done','done','active',''],
      TESTING: ['done','done','done','active'],
      FIXING: ['done','active','',''],
      READY: ['done','done','done','done'],
      FAILED: ['done','done','done','active'],
    };
    nodes.forEach((id,i) => {
      const node = $(`node-${id}`);
      const status = (statuses[stage] || [])[i];
      node.className = `agent-node ${status || ''}`;
      node.querySelector('.node-status').textContent = status === 'done' ? '✓' : status === 'active' ? '◉' : '○';
    });
    const steps = document.querySelectorAll('.track-step');
    const rank = stage === 'INTERVIEWING' ? 0 : stage === 'AWAITING_SPEC_APPROVAL' ? 1 : ['BUILDING','TESTING','FIXING','FAILED'].includes(stage) ? 2 : 3;
    steps.forEach((step,i) => { step.className = `track-step ${i < rank ? 'done' : i === rank ? 'active' : ''}`; });
    badge('pipeline-badge', stage === 'READY' ? 'PASSED' : stage === 'FAILED' ? 'NEEDS REVIEW' : stage === 'INTERVIEWING' ? 'IDLE' : stage.replace(/_/g,' '));
  }

  function renderEvents(current) {
    const events = (current.events || []).slice(-7).reverse();
    badge('event-count', `${current.events?.length || 0} events`);
    $('event-stream').innerHTML = events.length ? events.map(evt => `<div class="event-item"><span class="event-point"></span><div><span class="event-actor">${esc(evt.actor)}</span><span class="event-time">${esc(new Date(evt.at).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}))}</span><div>${esc(evt.message)}</div></div></div>`).join('') : '<div class="empty-events">No events yet.</div>';
    const reports = current.qa_reports || [];
    const progress = current.test_progress;
    $('test-progress').textContent = ['TESTING','FIXING'].includes(current.stage) && progress ? `Regression run ${progress.cycle}: ${progress.completed}/${progress.total} cases evaluated` : '';
    const first = reports[0], last = reports[reports.length - 1];
    const evidence = current.evidence_report;
    if (first && last && evidence) {
      const initial = new Map((first.results || []).map(r => [r.case_id, r]));
      const rows = (last.results || []).map(after => {
        const before = initial.get(after.case_id) || after;
        const verdict = r => `<span class="${r.passed ? 'pass' : 'fail'}">${r.passed ? '✓ PASS' : '✕ FAIL'}</span>`;
        return `<div class="case-row"><div class="case-head"><span><strong>${esc(after.case_id)}</strong> ${esc(after.name)}</span><span>${verdict(before)} <span class="case-arrow">→</span> ${verdict(after)}</span></div><details class="case-detail"><summary>Show actual output &amp; failure evidence</summary><div class="case-columns"><div><strong>BEFORE · ${esc(before.kind)}</strong><p><b>Input</b> ${esc(before.input)}</p><p><b>Expected</b> ${esc(before.expected_behavior)}</p><p><b>Actual response</b> ${esc(before.actual_output)}</p>${before.failure_reason ? `<p class="failure-reason"><b>Failure</b> ${esc(before.failure_reason)}</p>` : ''}</div><div><strong>AFTER · BUILD ${last.cycle}</strong><p><b>Actual response</b> ${esc(after.actual_output)}</p>${after.failure_reason ? `<p class="failure-reason"><b>Failure</b> ${esc(after.failure_reason)}</p>` : '<p class="pass">All checked criteria passed.</p>'}</div></div></details></div>`;
      }).join('');
      const repairs = (current.repair_log || []).map(item => `<div class="repair-item"><strong>Repair ${item.cycle}</strong><p>Failed cases: ${esc(item.failed_cases.join(', ') || 'Structural check')}</p>${Object.entries(item.changes || {}).map(([key,diff]) => `<details><summary>${esc(key)} updated · view diff</summary><div class="diff-before">− ${esc(JSON.stringify(diff.before))}</div><div class="diff-after">+ ${esc(JSON.stringify(diff.after))}</div></details>`).join('') || '<p>Guardrails rebuilt from QA evidence.</p>'}</div>`).join('');
      $('qa-container').innerHTML = `<div class="qa-box ${last.passed ? '' : 'failed'}"><div class="qa-title"><span>Before ${esc(evidence.initial_score)} <span class="case-arrow">→</span> After ${esc(evidence.final_score)}</span><span>${last.passed ? '✓ PASSED' : '✕ NEEDS WORK'}</span></div><div class="qa-note">${evidence.verified_by_real_models ? 'Real Gemini execution + independent model grading' : '⚠ OFFLINE SIMULATION — these outputs are synthetic, not real AI results.'}</div><div class="case-table-label">FIVE-CASE BEFORE / AFTER EVIDENCE</div>${rows}${repairs ? `<div class="case-table-label">ARCHITECT REPAIR DIFF</div>${repairs}` : ''}${(last.checks || []).filter(c => !c.passed).map(c => `<div class="qa-check fail">✕ ${esc(c.label)}: ${esc(c.detail)}</div>`).join('')}</div>`;
    } else $('qa-container').innerHTML = '';
    $('pipeline-controls').hidden = current.stage !== 'BUILDING' || !!current.agent_artifact;
    if (current.error) toast(current.error, true);
  }

  function renderSandbox(current) {
    const isReady = current.stage === 'READY';
    $('sandbox-locked').hidden = isReady;
    $('sandbox-ready').hidden = !isReady;
    badge('sandbox-badge', isReady ? (current.mode === 'live' ? 'VERIFIED' : 'SIMULATION') : 'LOCKED');
    if (!isReady) return;
    const artifact = current.agent_artifact;
    $('ready-agent-name').textContent = artifact.name;
    $('ready-agent-meta').textContent = `${current.qa_reports.length} QA cycle(s) · ${current.mode === 'demo' ? 'offline simulator' : artifact.model}`;
    const botActive = telegramStatus?.listener_running && !telegramStatus?.listener_error;
    const botEnabled = telegramStatus?.enabled !== false;
    $('telegram-live-status').textContent = !botActive ? '● Listener offline' : botEnabled ? '● LIVE · Replies on' : '● Paused';
    $('telegram-live-hint').textContent = telegramStatus?.listener_error ||
      (botActive ? 'Send /weather for live Debrecen weather, or send a normal message to this bot. /pause and /resume also work in Telegram.' :
        'Start the FastAPI server with TELEGRAM_BOT_TOKEN set. Check /health/telegram if incoming replies do not arrive.');
    $('telegram-test').disabled = telegramBusy;
    $('telegram-toggle').disabled = telegramBusy;
    $('telegram-toggle').textContent = botEnabled ? '⏸ Pause replies' : '▶ Resume replies';
    $('artifact-prompt').textContent = artifact.system_prompt;
    $('remaining-limitations').innerHTML = `<ul>${(current.evidence_report?.remaining_limitations || []).map(x => `<li>${esc(x)}</li>`).join('')}</ul>`;
    $('export-artifact').href = `/projects/${encodeURIComponent(current.project_id)}/export`;
    const target = $('agent-messages');
    const items = current.agent_history.length ? current.agent_history : [{role:'assistant',content:'Your agent passed QA! Ask a question to begin.'}];
    const stayDown = target.scrollTop + target.clientHeight + 100 >= target.scrollHeight;
    target.innerHTML = items.map(item => messageHtml(item, artifact.name.toUpperCase())).join('');
    if (stayDown) target.scrollTop = target.scrollHeight;
  }

  function renderTelegram() {
    const connected = Boolean(state && telegramProjectId === state.project_id && telegramStatus?.verified);
    $('telegram-onboarding').hidden = connected;
    $('agent-workspace').hidden = !connected;
    if (connected) return;
    const pendingCode = Boolean(telegramStatus?.pending);
    $('telegram-verify-badge').textContent = pendingCode ? 'CODE SENT' : 'NOT VERIFIED';
    $('telegram-code-wrap').hidden = !pendingCode;
    $('telegram-send-code').disabled = telegramBusy || !config.channels?.telegram;
    $('telegram-verify').disabled = telegramBusy || !pendingCode;
    if (telegramStatus?.username) $('telegram-username').value = telegramStatus.username;
    if (pendingCode) {
      $('telegram-verify-status').textContent = `A code was sent to ${telegramStatus.username}. Expires ${new Date(telegramStatus.expires_at).toLocaleTimeString()}. ${telegramStatus.attempts_remaining} attempts remaining.`;
    } else {
      $('telegram-verify-status').textContent = config.channels?.telegram ? 'Send /start to our bot, enter your @username, then request a code. Codes expire after 10 minutes.' : 'Set TELEGRAM_BOT_TOKEN in your .env and restart the server to begin.';
    }
    const link = config.telegram_bot_url;
    $('telegram-bot-link').hidden = !link;
    if (link) $('telegram-bot-link').href = link;
    $('telegram-bot-hint').hidden = Boolean(link);
  }

  async function refreshTelegram(projectId) {
    const result = await api(`/projects/${encodeURIComponent(projectId)}/telegram/status`);
    if (!state || state.project_id !== projectId) return;
    telegramProjectId = projectId;
    telegramStatus = result.telegram;
    renderTelegram();
    if (state.stage === 'READY') renderSandbox(state);
  }

  async function telegramAction(fn) {
    if (telegramBusy || !state) return;
    telegramBusy = true;
    renderTelegram();
    try { await fn(); }
    catch (error) { toast(error.message || 'Telegram verification failed.', true); }
    finally { telegramBusy = false; renderTelegram(); if (state?.stage === 'READY') renderSandbox(state); }
  }

  $('telegram-send-code').addEventListener('click', () => telegramAction(async () => {
    const username = $('telegram-username').value.trim();
    if (!/^@[A-Za-z0-9_]{5,32}$/.test(username)) throw new Error('Enter your Telegram @username (for example @exampleuser).');
    const projectId = state.project_id;
    const result = await api(`/projects/${projectId}/telegram/request-code`, {method:'POST',body:{username}});
    if (state.project_id !== projectId) return;
    telegramProjectId = projectId;
    telegramStatus = result.telegram;
    $('telegram-code').value = '';
    toast('Verification code sent. Check your Telegram chat.');
    $('telegram-code').focus();
  }));
  $('telegram-verify').addEventListener('click', () => telegramAction(async () => {
    const code = $('telegram-code').value.trim();
    if (!/^[0-9]{6}$/.test(code)) throw new Error('Enter the six-digit code from Telegram.');
    const projectId = state.project_id;
    const result = await api(`/projects/${projectId}/telegram/verify`, {method:'POST',body:{code}});
    if (state.project_id !== projectId) return;
    telegramProjectId = projectId;
    telegramStatus = result.telegram;
    $('telegram-code').value = '';
    toast('Telegram verified! You can now design and test your agent.');
    renderTelegram();
  }));
  $('telegram-code').addEventListener('keydown', event => {
    if (event.key === 'Enter') { event.preventDefault(); $('telegram-verify').click(); }
  });

  $('telegram-test').addEventListener('click', () => telegramAction(async () => {
    await api(`/projects/${state.project_id}/telegram/test`, {method:'POST'});
    toast('Real Telegram test message sent. Open your Telegram bot chat!');
  }));
  $('telegram-toggle').addEventListener('click', () => telegramAction(async () => {
    const enabled = telegramStatus?.enabled === false;
    await api(`/projects/${state.project_id}/telegram/control`, {method:'POST',body:{enabled}});
    await refreshTelegram(state.project_id);
    renderSandbox(state);
    toast(enabled ? 'Telegram replies resumed.' : 'Telegram replies paused. Use /resume in Telegram to reactivate.');
  }));

  function render(current) {
    const changedProject = state?.project_id !== current.project_id;
    state = current;
    if (changedProject) {
      telegramProjectId = current.project_id;
      telegramStatus = null;
      $('telegram-username').value = '';
      $('telegram-code').value = '';
      refreshTelegram(current.project_id).catch(error => toast(error.message, true));
    }
    renderTelegram();
    renderMessages(current);
    renderRail(current);
    renderEvents(current);
    renderSandbox(current);
    if (['BUILDING','FIXING','TESTING'].includes(current.stage) && (current.agent_artifact || current.stage !== 'BUILDING' || current.pipeline_started)) schedulePoll();
    else clearTimeout(pollTimer);
  }

  function schedulePoll() {
    clearTimeout(pollTimer);
    pollTimer = setTimeout(async () => {
      if (!state) return;
      try { render(await api(`/projects/${state.project_id}/state`)); }
      catch (error) { toast(error.message, true); }
    }, 1000);
  }

  async function newProject() {
    const created = await api('/api/projects', {method:'POST'});
    localStorage.setItem('agentForgeProjectId', created.project_id);
    $('requirement-text').value = '';
    $('requirement-error').hidden = true;
    render(created);
    toast('Fresh workspace created. Verify Telegram to unlock agent creation.');
  }

  $('new-project').addEventListener('click', () => action(newProject));
  $('send-requirement').addEventListener('click', () => action(async () => {
    const message = $('requirement-text').value.trim();
    if (!message) throw new Error('Please describe your idea or requested revision.');
    $('requirement-error').hidden = true;
    let result;
    try {
      result = await api(`/projects/${state.project_id}/message`, {method:'POST',body:{message}});
    } catch (error) {
      $('requirement-error').textContent = `Specification could not be generated: ${error.message} You can retry without losing your idea.`;
      $('requirement-error').hidden = false;
      throw error;
    }
    $('requirement-text').value = '';
    render(result.state);
    if (result.state.stage === 'AWAITING_SPEC_APPROVAL') toast('Specification drafted. Review it on the left.');
  }));
  $('requirement-text').addEventListener('keydown', event => { if (event.key === 'Enter' && (event.metaKey || event.ctrlKey)) {event.preventDefault();$('send-requirement').click();} });
  $('approve-spec').addEventListener('click', () => action(async () => {
    const next = await api(`/projects/${state.project_id}/approve`, {method:'POST',body:{spec_version: state.spec_version}});
    render(next);
    toast('Specification approved. You can now run the build pipeline.');
  }));
  $('start-pipeline').addEventListener('click', () => action(async () => {
    await api(`/projects/${state.project_id}/run-pipeline`, {method:'POST',body:{inject_demo_fault:$('inject-fault').checked}});
    render(await api(`/projects/${state.project_id}/state`));
    toast('Pipeline started. Watch the activity log for progress.');
  }));
  $('agent-form').addEventListener('submit', event => { event.preventDefault(); action(async () => {
    const message = $('agent-input').value.trim();
    if (!message) return;
    $('agent-input').value = '';
    // Optimistic bubble while the server prepares its answer.
    state.agent_history.push({role:'user', content:message});
    state.agent_history.push({role:'assistant', content:'Thinking…'});
    renderSandbox(state);
    try { await api(`/projects/${state.project_id}/agent/chat`, {method:'POST',body:{message}}); }
    finally { render(await api(`/projects/${state.project_id}/state`)); }
  }); });

  async function init() {
    try {
      config = await api('/api/config');
      const pill = $('mode-pill');
      pill.className = `status-pill ${config.mode}`;
      pill.textContent = config.mode === 'live' ? `● GEMINI KEY SET · ${config.model}` : '● OFFLINE SIMULATION · NO API KEY';
      $('inject-fault').closest('label').hidden = config.mode === 'live';
      const id = localStorage.getItem('agentForgeProjectId');
      if (id) {
        try { render(await api(`/projects/${id}/state`)); return; }
        catch { localStorage.removeItem('agentForgeProjectId'); }
      }
      await newProject();
    } catch (error) { toast(`Cannot reach the backend: ${error.message}. Start FastAPI to use the full workshop.`, true); }
  }
  // Keep pause/resume and listener-health indicators accurate when commands
  // are sent from Telegram instead of from the website.
  setInterval(() => {
    if (state?.stage === 'READY' && telegramStatus?.verified && !telegramBusy)
      refreshTelegram(state.project_id).catch(() => {});
  }, 10000);
  init();
})();
