"""Keep the read-only weather feature after removing timed automations."""
import unittest
from unittest.mock import AsyncMock, patch

import httpx
from fastapi.testclient import TestClient

from backend.weather import weather_briefing


class WeatherTests(unittest.IsolatedAsyncioTestCase):
    async def test_debrecen_weather_uses_current_open_meteo_data(self):
        client = AsyncMock()
        client.__aenter__.return_value = client
        client.get.side_effect = [
            httpx.Response(200, request=httpx.Request("GET", "https://geocoding-api.open-meteo.com/v1/search"),
                json={"results": [{"name": "Debrecen", "country": "Hungary",
                "latitude": 47.5, "longitude": 21.6, "timezone": "Europe/Budapest"}]}),
            httpx.Response(200, request=httpx.Request("GET", "https://api.open-meteo.com/v1/forecast"),
                json={"current": {"time": "2026-11-21T16:00", "temperature_2m": 9.5,
                "apparent_temperature": 8, "relative_humidity_2m": 70, "precipitation": 0,
                "weather_code": 3, "wind_speed_10m": 12}}),
        ]
        with patch("backend.weather.httpx.AsyncClient", return_value=client):
            briefing = await weather_briefing("Debrecen")
        self.assertIn("Debrecen, Hungary", briefing)
        self.assertIn("9.5°C", briefing)
        self.assertIn("overcast", briefing)

    async def test_unknown_city_does_not_invent_conditions(self):
        client = AsyncMock()
        client.__aenter__.return_value = client
        client.get.return_value = httpx.Response(200, request=httpx.Request("GET", "https://geocoding-api.open-meteo.com/v1/search"), json={"results": []})
        with patch("backend.weather.httpx.AsyncClient", return_value=client):
            with self.assertRaisesRegex(Exception, "No weather location"):
                await weather_briefing("UnknownPlace")


class WeatherHttpTests(unittest.TestCase):
    def test_route_remains_read_only(self):
        from backend import main
        with patch("backend.main.weather_briefing", new_callable=AsyncMock, return_value="Debrecen 10°C"), TestClient(main.app) as client:
            response = client.get("/api/weather?city=Debrecen")
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.json()["message"], "Debrecen 10°C")
