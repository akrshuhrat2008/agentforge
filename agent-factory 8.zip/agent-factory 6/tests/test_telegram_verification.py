"""Offline Telegram proof-of-possession, security and API integration tests."""
import os
import sqlite3
import tempfile
import time
import unittest
from unittest.mock import AsyncMock, patch

import httpx
from fastapi.testclient import TestClient

from backend.store import ProjectStore
from backend.telegram_verification import (
    TelegramVerificationStore, VerificationError, send_verification_code,
)


USERNAME = "@exampleuser"
CHAT_ID = "12345678"


class TelegramCodeTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.tmp.name, "test.sqlite")
        self.verifier = TelegramVerificationStore(self.path)
        self.env_patch = patch.dict(os.environ, {"TELEGRAM_BOT_TOKEN": "test-token"})
        self.env_patch.start()
        self.sender_patch = patch("backend.telegram_verification.send_verification_code", new_callable=AsyncMock)
        self.sender = self.sender_patch.start()
        self.resolver_patch = patch.object(self.verifier, "_resolve_username", new_callable=AsyncMock, return_value=CHAT_ID)
        self.resolver = self.resolver_patch.start()

    async def asyncTearDown(self):
        self.resolver_patch.stop()
        self.sender_patch.stop()
        self.env_patch.stop()
        self.verifier.close()
        self.tmp.cleanup()

    async def test_code_sent_to_resolved_private_chat_not_returned(self):
        pending = await self.verifier.request_code("project-a", USERNAME)
        self.assertTrue(pending["pending"])
        self.assertEqual(pending["username"], USERNAME)
        self.assertNotIn("chat_id", pending)
        self.resolver.assert_awaited_once_with(USERNAME)
        sent_chat, code = self.sender.await_args.args
        self.assertEqual(sent_chat, CHAT_ID)
        self.assertRegex(code, r"^[0-9]{6}$")
        self.assertNotIn(code, repr(pending))
        self.assertNotIn(code, repr(self.verifier.status("project-a")))
        self.assertIsNone(self.verifier.verified_chat_id("project-a"))
        verified = self.verifier.verify("project-a", code)
        self.assertTrue(verified["verified"])
        self.assertEqual(verified["username"], USERNAME)
        self.assertEqual(self.verifier.verified_chat_id("project-a"), CHAT_ID)
        self.assertIsNone(self.verifier._row("project-a")[1])

    async def test_five_wrong_guesses_or_expiry_deny_verification(self):
        await self.verifier.request_code("project-a", USERNAME)
        code = self.sender.await_args.args[1]
        wrong = "000000" if code != "000000" else "111111"
        for _ in range(5):
            with self.assertRaisesRegex(VerificationError, "Incorrect"):
                self.verifier.verify("project-a", wrong)
        self.assertFalse(self.verifier.status("project-a")["pending"])
        with self.assertRaises(VerificationError):
            self.verifier.verify("project-a", code)

        self.resolver.return_value = "99999999"
        await self.verifier.request_code("project-b", "@otheruser")
        second_code = self.sender.await_args.args[1]
        with self.verifier.lock:
            self.verifier.db.execute("UPDATE telegram_verifications SET expires_at=? WHERE project_id='project-b'", (time.time() - 1,))
            self.verifier.db.commit()
        with self.assertRaisesRegex(VerificationError, "expired"):
            self.verifier.verify("project-b", second_code)

    async def test_codes_are_project_bound_and_rate_limited(self):
        await self.verifier.request_code("project-a", USERNAME)
        code = self.sender.await_args.args[1]
        with self.assertRaisesRegex(VerificationError, "Request"):
            self.verifier.verify("project-b", code)
        with self.assertRaisesRegex(VerificationError, "60 seconds"):
            await self.verifier.request_code("project-b", USERNAME)
        self.sender.assert_awaited_once()

    async def test_invalid_usernames_rejected_and_delivery_does_not_create_code(self):
        for bad in ("12345678", "@abc", "@name with spaces", "", "@"):
            with self.assertRaises(VerificationError):
                await self.verifier.request_code("project-a", bad)
        self.sender.side_effect = VerificationError("Telegram failed")
        with self.assertRaises(VerificationError):
            await self.verifier.request_code("project-a", USERNAME)
        self.assertFalse(self.verifier.status("project-a")["pending"])

    async def test_restart_preserves_existing_verified_chat(self):
        await self.verifier.request_code("project-a", USERNAME)
        self.verifier.verify("project-a", self.sender.await_args.args[1])
        second = TelegramVerificationStore(self.path)
        try:
            self.assertEqual(second.verified_chat_id("project-a"), CHAT_ID)
            self.assertEqual(second.status("project-a")["username"], USERNAME)
        finally:
            second.close()


class TelegramLookupTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.verifier = TelegramVerificationStore(os.path.join(self.tmp.name, "lookups.sqlite"))
        self.env = patch.dict(os.environ, {"TELEGRAM_BOT_TOKEN": "secret-bot-token"})
        self.env.start()

    async def asyncTearDown(self):
        self.env.stop()
        self.verifier.close()
        self.tmp.cleanup()

    async def test_recent_private_start_maps_username_case_insensitively(self):
        client = AsyncMock()
        client.__aenter__.return_value = client
        client.get.return_value = httpx.Response(200, json={"ok": True, "result": [
            {"update_id": 45, "message": {"date": int(time.time()), "text": "/start",
                "chat": {"id": 12345678, "type": "private"},
                "from": {"id": 12345678, "username": "ExampleUser"}}},
            {"update_id": 46, "message": {"date": int(time.time()), "text": "/start",
                "chat": {"id": -10042, "type": "supergroup"},
                "from": {"id": 1234, "username": "GroupAdmin"}}},
        ]})
        with patch("backend.telegram_verification.httpx.AsyncClient", return_value=client):
            self.assertEqual(await self.verifier._resolve_username(USERNAME), CHAT_ID)
        self.assertIsNone(self.verifier.db.execute("SELECT chat_id FROM telegram_known_users WHERE username_key='groupadmin'").fetchone())
        self.assertNotIn("secret-bot-token", repr(client.get.call_args.kwargs["params"]))
        self.assertEqual(self.verifier.db.execute("SELECT next_offset FROM telegram_update_offsets").fetchone()[0], 47)

    async def test_no_recent_start_explains_how_to_fix_it(self):
        client = AsyncMock()
        client.__aenter__.return_value = client
        client.get.return_value = httpx.Response(200, json={"ok": True, "result": []})
        with patch("backend.telegram_verification.httpx.AsyncClient", return_value=client):
            with self.assertRaisesRegex(VerificationError, "/start"):
                await self.verifier._resolve_username(USERNAME)

    async def test_telegram_webhook_conflict_is_explained_without_leaking_token(self):
        client = AsyncMock()
        client.__aenter__.return_value = client
        client.get.return_value = httpx.Response(409, json={"ok": False, "description": "secret-bot-token"})
        with patch("backend.telegram_verification.httpx.AsyncClient", return_value=client):
            with self.assertRaises(VerificationError) as ctx:
                await self.verifier._resolve_username(USERNAME)
        self.assertIn("webhook", str(ctx.exception))
        self.assertNotIn("secret-bot-token", str(ctx.exception))

    async def test_code_delivery_uses_resolved_id_only(self):
        client = AsyncMock()
        client.__aenter__.return_value = client
        client.post.return_value = httpx.Response(200, json={"ok": True, "result": {"message_id": 4}})
        with patch("backend.telegram_verification.httpx.AsyncClient", return_value=client):
            await send_verification_code(CHAT_ID, "024681")
        args, kwargs = client.post.await_args
        self.assertIn("/sendMessage", args[0])
        self.assertEqual(kwargs["json"]["chat_id"], CHAT_ID)
        self.assertIn("024681", kwargs["json"]["text"])
        self.assertNotIn("secret-bot-token", str(kwargs["json"]))


class TelegramHttpTests(unittest.TestCase):
    def test_username_verification_required_and_automation_endpoints_removed(self):
        from backend import main
        with tempfile.TemporaryDirectory() as tmp:
            store = ProjectStore(os.path.join(tmp, "api.sqlite"))
            verifier = TelegramVerificationStore(os.path.join(tmp, "api.sqlite"))
            captured = []

            async def capture(chat_id, code):
                captured.append((chat_id, code))

            with patch.object(main, "store", store), \
                 patch.object(main, "telegram_verification", verifier), \
                 patch.object(main.telegram_runtime, "start"), \
                 patch.object(verifier, "_resolve_username", new_callable=AsyncMock, return_value=CHAT_ID), \
                 patch("backend.telegram_verification.send_verification_code", side_effect=capture), \
                 patch.dict(os.environ, {"TELEGRAM_BOT_TOKEN": "fake-token"}), \
                 TestClient(main.app) as client:
                project = client.post("/api/projects").json()["project_id"]
                self.assertEqual(client.post(f"/projects/{project}/message", json={"message": "Build a bot"}).status_code, 403)
                self.assertEqual(client.post(f"/projects/{project}/approve", json={"spec_version": 1}).status_code, 403)
                self.assertEqual(client.post(f"/projects/{project}/run-pipeline", json={}).status_code, 403)
                self.assertEqual(client.post(f"/projects/{project}/agent/chat", json={"message": "hello"}).status_code, 403)
                self.assertEqual(client.get(f"/projects/{project}/automation").status_code, 404)
                self.assertEqual(client.post(f"/projects/{project}/automation/start").status_code, 404)
                self.assertEqual(client.post(f"/projects/{project}/telegram/request-code", json={"chat_id": CHAT_ID}).status_code, 422)
                sent = client.post(f"/projects/{project}/telegram/request-code", json={"username": USERNAME})
                self.assertEqual(sent.status_code, 200)
                self.assertTrue(sent.json()["telegram"]["pending"])
                self.assertEqual(sent.json()["telegram"]["username"], USERNAME)
                self.assertNotIn("chat_id", sent.text)
                self.assertEqual(captured[0][0], CHAT_ID)
                self.assertNotIn(captured[0][1], sent.text)
                wrong = "000000" if captured[0][1] != "000000" else "111111"
                self.assertEqual(client.post(f"/projects/{project}/telegram/verify", json={"code": wrong}).status_code, 409)
                verified = client.post(f"/projects/{project}/telegram/verify", json={"code": captured[0][1]})
                self.assertEqual(verified.status_code, 200)
                self.assertTrue(verified.json()["telegram"]["verified"])
                self.assertEqual(verifier.verified_chat_id(project), CHAT_ID)
            store.db.close()
            verifier.close()


class LegacyMigrationTests(unittest.TestCase):
    def test_existing_v4_db_gains_username_column_without_resetting_telegram(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "legacy.sqlite")
            db = sqlite3.connect(path)
            db.execute("""CREATE TABLE telegram_verifications (project_id TEXT PRIMARY KEY,
                chat_id TEXT NOT NULL, code_hash TEXT, expires_at REAL, attempts INTEGER,
                verified_at REAL, last_sent_at REAL)""")
            db.execute("INSERT INTO telegram_verifications VALUES ('old','1234',NULL,NULL,0,?,NULL)", (time.time(),))
            db.commit()
            db.close()
            new = TelegramVerificationStore(path)
            self.assertEqual(new.verified_chat_id("old"), "1234")
            self.assertIsNone(new.status("old")["username"])
            new.close()
