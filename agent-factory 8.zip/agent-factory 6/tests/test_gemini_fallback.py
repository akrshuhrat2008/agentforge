"""Offline Gemini service-overload regression tests; no API key is contacted."""
import os
import unittest
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
from openai import APIStatusError

from backend import ai


def overloaded():
    response = httpx.Response(503, request=httpx.Request("POST", "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"), text="overloaded")
    return APIStatusError("The model is experiencing high demand", response=response, body=None)


class GeminiFallbackTests(unittest.IsolatedAsyncioTestCase):
    async def test_smart_model_defaults_to_documented_id(self):
        with patch.dict(os.environ, {"MODEL_SMART": "", "MODEL_SMART_FALLBACK": ""}):
            # Defaults only apply when the env variable is absent.
            os.environ.pop("MODEL_SMART", None)
            os.environ.pop("MODEL_SMART_FALLBACK", None)
            self.assertEqual(ai.model_name("smart"), "gemini-3.8-flash")
            self.assertEqual(ai.fallback_model("smart"), "gemini-3.6-flash")

    async def test_http_503_on_primary_switches_to_fallback(self):
        reply = MagicMock(choices=[MagicMock(message=MagicMock(content="Success"))])
        client = AsyncMock()
        client.__aenter__.return_value = client
        client.chat.completions.create.side_effect = [overloaded(), overloaded(), reply]
        with patch.dict(os.environ, {"GEMINI_API_KEY": "fake-key", "MODEL_SMART": "gemini-3.8-flash",
                                      "MODEL_SMART_FALLBACK": "gemini-3.6-flash"}), \
             patch("openai.AsyncOpenAI", return_value=client), \
             patch("backend.ai.asyncio.sleep", new_callable=AsyncMock):
            result = await ai.complete("Respond briefly", "Hello", role="smart")
        self.assertEqual(result, "Success")
        used = [call.kwargs["model"] for call in client.chat.completions.create.await_args_list]
        self.assertEqual(used, ["gemini-3.8-flash", "gemini-3.8-flash", "gemini-3.6-flash"])

    async def test_dual_503_failure_reports_help_without_raw_api_error(self):
        client = AsyncMock()
        client.__aenter__.return_value = client
        client.chat.completions.create.side_effect = [overloaded() for _ in range(4)]
        with patch.dict(os.environ, {"GEMINI_API_KEY": "fake-key", "MODEL_SMART": "gemini-3.8-flash",
                                      "MODEL_SMART_FALLBACK": "gemini-3.6-flash"}), \
             patch("openai.AsyncOpenAI", return_value=client), \
             patch("backend.ai.asyncio.sleep", new_callable=AsyncMock):
            with self.assertRaises(RuntimeError) as ctx:
                await ai.complete("Respond briefly", "Hello", role="smart")
        message = str(ctx.exception)
        self.assertIn("HTTP 503", message)
        self.assertIn("gemini-3.6-flash", message)
        self.assertNotIn("fake-key", message)
