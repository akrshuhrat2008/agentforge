"""Offline proof of Telegram live routing, identity gating, and pause/resume."""
import os
import tempfile
import time
import unittest
from unittest.mock import AsyncMock, patch

import httpx
from fastapi.testclient import TestClient

from backend.store import ProjectStore
from backend.telegram_verification import TelegramVerificationStore
from backend.telegram_runtime import TelegramRuntime


CHAT_ID = "543210987"


class TelegramLiveTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        path = os.path.join(self.tmp.name, "bridge.sqlite")
        self.store = ProjectStore(path)
        self.verifier = TelegramVerificationStore(path)
        self.bot = TelegramRuntime(self.verifier, self.store)
        project = self.store.create()
        project["stage"] = "READY"
        project["agent_artifact"] = {"name": "Debrecen Weather Agent"}
        self.store.save(project)
        self.project_id = project["project_id"]
        with self.verifier.lock:
            self.verifier.db.execute("INSERT INTO telegram_verifications (project_id,chat_id,verified_at) VALUES (?,?,?)",
                                     (self.project_id, CHAT_ID, time.time()))
            self.verifier.db.commit()
        self.send_patch = patch("backend.telegram_runtime.telegram_send", new_callable=AsyncMock)
        self.send = self.send_patch.start()

    async def asyncTearDown(self):
        await self.bot.stop()
        self.send_patch.stop()
        self.store.db.close()
        self.verifier.close()
        self.tmp.cleanup()

    def msg(self, text, chat_id=CHAT_ID):
        n = int(chat_id)
        return {"chat": {"id": n, "type": "private"}, "from": {"id": n}, "text": text}

    async def test_live_weather_uses_weather_service_and_sends_actual_text(self):
        with patch("backend.telegram_runtime.weather_briefing", new_callable=AsyncMock,
                   return_value="Live 11°C, Open-Meteo") as weather:
            await self.bot.handle_message(self.msg("weather"))
        weather.assert_awaited_once_with("Debrecen")
        self.send.assert_awaited_once_with(CHAT_ID, "Live 11°C, Open-Meteo")

    async def test_normal_chat_runs_approved_generated_agent(self):
        with patch("backend.telegram_runtime.pipeline.sandbox_chat", new_callable=AsyncMock,
                   return_value={"reply": "Hello from approved agent"}) as sandbox:
            await self.bot.handle_message(self.msg("hey"))
        sandbox.assert_awaited_once()
        self.send.assert_awaited_once_with(CHAT_ID, "Hello from approved agent")

    async def test_unverified_chat_cannot_invoke_tools_or_get_reply(self):
        with patch("backend.telegram_runtime.pipeline.sandbox_chat", new_callable=AsyncMock) as sandbox:
            await self.bot.handle_message(self.msg("hey", chat_id="9990001"))
        sandbox.assert_not_awaited()
        self.send.assert_not_awaited()

    async def test_pause_resume_and_restart_preserve_state(self):
        await self.bot.handle_message(self.msg("/pause"))
        self.assertFalse(self.verifier.bot_enabled(self.project_id))
        self.send.reset_mock()
        with patch("backend.telegram_runtime.weather_briefing", new_callable=AsyncMock) as weather:
            await self.bot.handle_message(self.msg("weather"))
        weather.assert_not_awaited()
        self.send.assert_not_awaited()
        new_verifier = TelegramVerificationStore(self.verifier.db.execute("PRAGMA database_list").fetchone()[2])
        try:
            self.assertFalse(new_verifier.bot_enabled(self.project_id))
        finally:
            new_verifier.close()
        await self.bot.handle_message(self.msg("/resume"))
        self.assertTrue(self.verifier.bot_enabled(self.project_id))
        self.send.assert_awaited_once()

    async def test_ready_project_required_for_test_notification(self):
        await self.bot.send_test(self.project_id)
        self.send.assert_awaited_once()
        with self.assertRaisesRegex(ValueError, "10 seconds"):
            await self.bot.send_test(self.project_id)
        project = self.store.get(self.project_id)
        project["stage"] = "FAILED"
        self.store.save(project)
        with self.assertRaisesRegex(ValueError, "pass QA"):
            await self.bot.send_test(self.project_id)

    async def test_verification_fetch_dispatched_telegram_message_not_lost(self):
        # A code request and the poller share one getUpdates reader.
        update = {"update_id": 20, "message": {**self.msg("weather"), "date": int(time.time())}}
        client = AsyncMock()
        client.__aenter__.return_value = client
        client.get.return_value = httpx.Response(200, json={"ok": True, "result": [update]})
        with patch.dict(os.environ, {"TELEGRAM_BOT_TOKEN": "fake-token"}), \
             patch("backend.telegram_verification.httpx.AsyncClient", return_value=client), \
             patch("backend.telegram_runtime.weather_briefing", new_callable=AsyncMock,
                   return_value="Live reading"):
            await self.verifier._refresh_known_users()
            if self.bot.pending:
                await __import__("asyncio").gather(*self.bot.pending)
        self.send.assert_awaited_once_with(CHAT_ID, "Live reading")
        self.assertEqual(self.verifier.db.execute("SELECT next_offset FROM telegram_update_offsets").fetchone()[0], 21)


class TelegramLiveHttpTests(unittest.TestCase):
    def test_web_controls_and_test_delivery(self):
        from backend import main
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "http.sqlite")
            store = ProjectStore(path)
            verifier = TelegramVerificationStore(path)
            runtime = TelegramRuntime(verifier, store)
            project = store.create()
            project["stage"] = "READY"
            project["agent_artifact"] = {"name": "Weather Bot"}
            store.save(project)
            pid = project["project_id"]
            with patch.object(main, "store", store), patch.object(main, "telegram_verification", verifier), \
                 patch.object(main, "telegram_runtime", runtime), patch.object(runtime, "start"), \
                 patch("backend.telegram_runtime.telegram_send", new_callable=AsyncMock) as sent, \
                 TestClient(main.app) as client:
                self.assertEqual(client.post(f"/projects/{pid}/telegram/test").status_code, 403)
                with verifier.lock:
                    verifier.db.execute("INSERT INTO telegram_verifications (project_id, chat_id, verified_at) VALUES (?,?,?)",
                                        (pid, CHAT_ID, time.time()))
                    verifier.db.commit()
                res = client.post(f"/projects/{pid}/telegram/test")
                self.assertEqual(res.status_code, 200, res.text)
                self.assertTrue(res.json()["sent"])
                sent.assert_awaited_once()
                self.assertEqual(client.post(f"/projects/{pid}/telegram/test").status_code, 409)
                paused = client.post(f"/projects/{pid}/telegram/control", json={"enabled": False})
                self.assertEqual(paused.status_code, 200)
                self.assertFalse(client.get(f"/projects/{pid}/telegram/status").json()["telegram"]["enabled"])
                self.assertTrue(client.post(f"/projects/{pid}/telegram/control", json={"enabled": True}).json()["enabled"])
            store.db.close()
            verifier.close()

