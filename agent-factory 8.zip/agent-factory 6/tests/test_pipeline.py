import asyncio
import os
import tempfile
import unittest
from unittest.mock import AsyncMock, patch

from backend import pipeline
from backend.store import ProjectStore
from backend.tools import arithmetic, execute_tool


EXAMPLE = "Build an AI agent that helps international students plan university paperwork, ask clear questions, and create checklists."


class TestWorkflow(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = ProjectStore(os.path.join(self.temp.name, "test.db"))
        self.env = patch.dict(os.environ, {"OPENAI_API_KEY": ""})
        self.env.start()

    async def asyncTearDown(self):
        self.env.stop()
        self.store.db.close()
        self.temp.cleanup()

    async def test_review_gate_and_chat(self):
        item = self.store.create()
        draft, _ = await pipeline.handle_message(self.store, item, EXAMPLE)
        self.assertEqual(draft["stage"], "AWAITING_SPEC_APPROVAL")
        self.assertIsNone(draft["approved_spec"])
        with self.assertRaisesRegex(ValueError, "Use the Approve Spec"):
            await pipeline.handle_message(self.store, draft, "approve")
        revised, _ = await pipeline.handle_message(self.store, draft, "Please support a clear checklist for students.")
        self.assertEqual(revised["spec_version"], 2)
        with self.assertRaisesRegex(ValueError, "latest version"):
            pipeline.approve_spec(self.store, revised, 1)
        approved = pipeline.approve_spec(self.store, revised, 2)
        self.assertEqual(approved["stage"], "BUILDING")
        self.assertEqual(approved["approved_spec"], revised["draft_spec"])
        await pipeline.run_pipeline(self.store, approved["project_id"], False)
        completed = self.store.get(approved["project_id"])
        self.assertEqual(completed["stage"], "READY")
        self.assertTrue(completed["qa_reports"][0]["passed"])
        response = await pipeline.sandbox_chat(self.store, completed, "Help me with paperwork")
        self.assertIn("[DEMO RESPONSE]", response["reply"])

    async def test_failing_qa_repairs_without_changing_approved_spec(self):
        item = self.store.create()
        draft, _ = await pipeline.handle_message(self.store, item, EXAMPLE)
        approved = pipeline.approve_spec(self.store, draft, 1)
        approved_spec = approved["approved_spec"].copy()
        await pipeline.run_pipeline(self.store, approved["project_id"], True)
        completed = self.store.get(approved["project_id"])
        self.assertEqual(completed["stage"], "READY")
        self.assertEqual(len(completed["qa_reports"]), 2)
        self.assertFalse(completed["qa_reports"][0]["passed"])
        self.assertTrue(completed["qa_reports"][1]["passed"])
        self.assertEqual(completed["approved_spec"], approved_spec)
        self.assertEqual(completed["fix_cycles"], 1)
        self.assertTrue(any(e["actor"] == "ARCHITECT" and "QA" in e["message"] for e in completed["events"]))
        self.assertEqual(len(completed["qa_reports"][0]["results"]), 5)
        self.assertEqual(completed["evidence_report"]["initial_score"], "4/5")
        self.assertEqual(completed["evidence_report"]["final_score"], "5/5")
        self.assertFalse(completed["evidence_report"]["verified_by_real_models"])
        self.assertEqual(len(completed["repair_log"]), 1)

    async def test_five_executions_and_independent_grading_each_cycle(self):
        """Exercise live orchestration with controlled fake Gemini outputs (not live API proof)."""
        item = self.store.create()
        draft, _ = await pipeline.handle_message(self.store, item, EXAMPLE)
        approved = pipeline.approve_spec(self.store, draft, 1)
        snapshot = approved["approved_spec"].copy()
        calls = []

        async def response(system_prompt, question, tools, history=None):
            calls.append(question)
            cycle = 1 if len(calls) <= 5 else 2
            if "deadline" in question and cycle == 1:
                return "UNVERIFIED claimed deadline", []
            return "I can help with a checklist; I cannot verify official deadlines or submit actions.", []

        async def model(instructions, content, role="fast"):
            if "Tech Builder" in instructions:
                return "Draft a clear checklist and disclose uncertainty."
            if "UNVERIFIED" in content:
                return '{"passed": false, "reason": "Fabricated deadline in actual output"}'
            return '{"passed": true, "reason": "Expectation met"}'

        with patch.object(pipeline.ai, "live_mode", return_value=True), \
             patch.object(pipeline.ai, "agent_reply", side_effect=response), \
             patch.object(pipeline.ai, "complete", side_effect=model), \
             patch.object(pipeline.ai, "complete_spec", new_callable=AsyncMock, return_value=approved["working_spec"]):
            await pipeline.run_pipeline(self.store, approved["project_id"], False)
        final = self.store.get(approved["project_id"])
        self.assertEqual(final["stage"], "READY")
        self.assertEqual(len(calls), 10)  # Five actual model executions in each of two runs.
        self.assertEqual([r["score"] for r in final["qa_reports"]], ["4/5", "5/5"])
        self.assertEqual(final["approved_spec"], snapshot)
        self.assertTrue(final["evidence_report"]["verified_by_real_models"])
        self.assertEqual(final["qa_reports"][0]["results"][2]["actual_output"], "UNVERIFIED claimed deadline")

    async def test_not_ready_cannot_chat(self):
        with self.assertRaisesRegex(ValueError, "not ready"):
            await pipeline.sandbox_chat(self.store, self.store.create(), "hello")


class TestAllowlistedTools(unittest.TestCase):
    def test_arithmetic(self):
        self.assertEqual(arithmetic("(7+3)*2"), 20)
        self.assertEqual(execute_tool("calculator", {"expression":"9/0"}).get("error"), 'float division by zero')

    def test_no_code_execution(self):
        self.assertIn("error", execute_tool("calculator", {"expression":"__import__('os').system('whoami')"}))
        self.assertEqual(execute_tool("shell", {"command":"ls"}), {"error":"Tool not allowed"})


if __name__ == "__main__":
    unittest.main()
