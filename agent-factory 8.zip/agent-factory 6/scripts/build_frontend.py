"""Mechanically assemble one self-contained frontend/index.html from editable sources."""
from pathlib import Path

root = Path(__file__).resolve().parent.parent / "frontend"
template_path = root / "index.template.html"
target = root / "index.html"
if not template_path.exists():
    original = target.read_text(encoding="utf-8")
    if '<link rel="stylesheet" href="/assets/styles.css">' not in original:
        raise ValueError("Cannot extract an editable HTML template")
    template_path.write_text(original, encoding="utf-8")
template = template_path.read_text(encoding="utf-8")
css = (root / "styles.css").read_text(encoding="utf-8")
js = (root / "app.js").read_text(encoding="utf-8")
# The page is entirely standalone; local fonts are supplied by OS fallbacks.
css = "\n".join(line for line in css.splitlines() if not line.startswith("@import url("))
html = template.replace('<link rel="stylesheet" href="/assets/styles.css">',
                        '<style data-agent-forge>\n' + css + '\n</style>')
html = html.replace('<script src="/assets/app.js" defer></script>',
                    '<script data-agent-forge>\n' + js.replace("</script", "<\\/script") + '\n</script>')
if 'href="/assets/styles.css"' in html or 'src="/assets/app.js"' in html:
    raise RuntimeError("Frontend build left an unbundled local asset")
target.write_text(html, encoding="utf-8")
print(f"Built {target} ({target.stat().st_size} bytes, standalone)")
