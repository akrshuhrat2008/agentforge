"""Telegram recipient proof-of-possession for Agent Forge projects.

A user first sends /start to the configured Telegram bot and enters their @username
on the website. The backend reads that /start from Telegram getUpdates and
resolves the username to an actual private chat ID. It sends a six-digit code
to that chat and unlocks the project only after the code is entered on the site.
Telegram cannot send private messages addressed solely by @username.
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone
import hashlib
import hmac
import os
import re
import secrets
import sqlite3
import threading
import time

import httpx

CODE_TTL_SECONDS = 10 * 60
RESEND_COOLDOWN_SECONDS = 60
MAX_SENDS_PER_HOUR = 3
MAX_VERIFY_ATTEMPTS = 5
USERNAME_PATTERN = re.compile(r"@[A-Za-z0-9_]{5,32}\Z")
RECENT_START_SECONDS = 3600


class VerificationError(ValueError):
    """Safe, user-visible validation or delivery error."""


def telegram_bot_url() -> str | None:
    username = os.getenv("TELEGRAM_BOT_USERNAME", "").strip().lstrip("@")
    if re.fullmatch(r"[A-Za-z0-9_]{5,32}", username):
        return f"https://t.me/{username}"
    return None


async def send_verification_code(chat_id: str, code: str) -> None:
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    if not token:
        raise VerificationError("Set TELEGRAM_BOT_TOKEN in .env before verifying a recipient.")
    message = (f"Agent Forge verification code: {code}\n\n"
               "Enter this code in Agent Forge within 10 minutes. "
               "If you did not request it, ignore this message. Do not share your code.")
    try:
        async with httpx.AsyncClient(timeout=12.0) as client:
            response = await client.post(
                f"https://api.telegram.org/bot{token}/sendMessage",
                json={"chat_id": chat_id, "text": message, "protect_content": True},
            )
            data = response.json()
        if response.status_code == 429:
            raise VerificationError("Telegram is rate-limiting requests. Try again later.")
        if response.status_code in (400, 403) or not data.get("ok"):
            raise VerificationError(
                "Telegram could not message this account. Open your bot in Telegram, "
                "send /start, and make sure your @username is correct."
            )
        if response.status_code != 200:
            raise VerificationError(f"Telegram verification delivery failed (HTTP {response.status_code}).")
    except (httpx.RequestError, ValueError) as exc:
        if isinstance(exc, VerificationError):
            raise
        # Never include request URL or raw provider error: URL contains bot token.
        raise VerificationError("Could not reach Telegram. Check your bot token and internet connection.") from None


class TelegramVerificationStore:
    def __init__(self, db_path: str):
        self.db = sqlite3.connect(db_path, check_same_thread=False)
        self.db.execute("""CREATE TABLE IF NOT EXISTS telegram_verifications (
            project_id TEXT PRIMARY KEY,
            chat_id TEXT NOT NULL,
            code_hash TEXT,
            expires_at REAL,
            attempts INTEGER NOT NULL DEFAULT 0,
            verified_at REAL,
            last_sent_at REAL
        )""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS telegram_verification_sends (
            project_id TEXT NOT NULL, chat_id TEXT NOT NULL, sent_at REAL NOT NULL
        )""")
        self.db.execute("CREATE INDEX IF NOT EXISTS idx_verification_sends_chat ON telegram_verification_sends(chat_id, sent_at)")
        # v4 projects retain their previously verified numeric chat IDs.
        columns = {row[1] for row in self.db.execute("PRAGMA table_info(telegram_verifications)")}
        if "username" not in columns:
            self.db.execute("ALTER TABLE telegram_verifications ADD COLUMN username TEXT")
        self.db.execute("""CREATE TABLE IF NOT EXISTS telegram_known_users (
            chat_id TEXT PRIMARY KEY, username_key TEXT NOT NULL UNIQUE, seen_at REAL NOT NULL
        )""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS telegram_update_offsets (
            id INTEGER PRIMARY KEY CHECK(id=1), next_offset INTEGER NOT NULL
        )""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS telegram_bot_controls (
            project_id TEXT PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1
        )""")
        self.db.commit()
        self.lock = threading.RLock()
        self.send_lock = asyncio.Lock()
        self.update_lock = asyncio.Lock()
        self.on_message = None  # Optional async runtime callback; verification still works alone.
        # A restart invalidates pending codes; verified recipients remain verified.
        self.pepper = secrets.token_bytes(32)

    def _digest(self, project_id: str, chat_id: str, code: str) -> str:
        return hmac.new(self.pepper, f"{project_id}:{chat_id}:{code}".encode(), hashlib.sha256).hexdigest()

    def _row(self, project_id: str):
        return self.db.execute("""SELECT chat_id, code_hash, expires_at, attempts, verified_at, last_sent_at, username
            FROM telegram_verifications WHERE project_id=?""", (project_id,)).fetchone()

    async def _refresh_known_users(self):
        """Consume private updates through one serialized Telegram reader.

        The bot runtime receives the same updates as verification, so requesting
        a code can never steal a live chat message from the bot poller.
        """
        token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
        if not token:
            raise VerificationError("Set TELEGRAM_BOT_TOKEN in .env before verifying Telegram.")
        async with self.update_lock:
            with self.lock:
                row = self.db.execute("SELECT next_offset FROM telegram_update_offsets WHERE id=1").fetchone()
                offset = row[0] if row else None
            try:
                async with httpx.AsyncClient(timeout=12.0) as client:
                    for _ in range(2):
                        params = {"limit": 100, "timeout": 3, "allowed_updates": '["message"]'}
                        if offset is not None:
                            params["offset"] = offset
                        response = await client.get(f"https://api.telegram.org/bot{token}/getUpdates", params=params)
                        if response.status_code == 409:
                            raise VerificationError("Bot has another getUpdates listener or an active webhook. Stop that listener before starting Agent Forge.")
                        if response.status_code == 401:
                            raise VerificationError("Telegram rejected your bot token. Check TELEGRAM_BOT_TOKEN in .env.")
                        if response.status_code != 200:
                            raise VerificationError(f"Telegram getUpdates failed (HTTP {response.status_code}).")
                        data = response.json()
                        if not data.get("ok") or not isinstance(data.get("result"), list):
                            raise VerificationError("Telegram returned an invalid update response.")
                        updates = data["result"]
                        now = time.time()
                        accepted = []
                        with self.lock:
                            for update in updates:
                                if not isinstance(update, dict) or not isinstance(update.get("update_id"), int):
                                    continue
                                offset = max(offset or 0, update["update_id"] + 1)
                                message = update.get("message") or {}
                                chat = message.get("chat") or {}
                                sender = message.get("from") or {}
                                if (chat.get("type") != "private" or chat.get("id") != sender.get("id")
                                    or not isinstance(message.get("text"), str)):
                                    continue
                                accepted.append(message)
                                username = sender.get("username")
                                first_word = message["text"].split(" ", 1)[0].split("@", 1)[0].lower()
                                if (first_word != "/start" or not isinstance(username, str)
                                    or not USERNAME_PATTERN.fullmatch("@" + username)
                                    or not isinstance(message.get("date"), int)
                                    or now - message["date"] > RECENT_START_SECONDS):
                                    continue
                                chat_id = str(chat["id"])
                                username_key = username.casefold()
                                self.db.execute("DELETE FROM telegram_known_users WHERE username_key=? AND chat_id<>?", (username_key, chat_id))
                                self.db.execute("""INSERT INTO telegram_known_users (chat_id, username_key, seen_at)
                                    VALUES (?, ?, ?) ON CONFLICT(chat_id) DO UPDATE SET
                                    username_key=excluded.username_key, seen_at=excluded.seen_at""",
                                    (chat_id, username_key, message["date"]))
                            if offset is not None:
                                self.db.execute("INSERT INTO telegram_update_offsets(id,next_offset) VALUES (1,?) ON CONFLICT(id) DO UPDATE SET next_offset=excluded.next_offset", (offset,))
                            self.db.commit()
                        if self.on_message:
                            for message in accepted:
                                await self.on_message(message)
                        if len(updates) < 100:
                            break
            except (httpx.RequestError, ValueError) as exc:
                if isinstance(exc, VerificationError):
                    raise
                raise VerificationError("Unable to reach Telegram to read bot messages. Check the token and connection.") from None

    async def _resolve_username(self, username: str) -> str:
        await self._refresh_known_users()
        with self.lock:
            row = self.db.execute("SELECT chat_id FROM telegram_known_users WHERE username_key=? AND seen_at>=?",
                                  (username[1:].casefold(), time.time() - RECENT_START_SECONDS)).fetchone()
        if not row:
            raise VerificationError(f"Could not find a recent /start from {username}. Open our bot, send /start, then retry on the website.")
        return row[0]

    def verified_chat_id(self, project_id: str) -> str | None:
        with self.lock:
            row = self._row(project_id)
            return row[0] if row and row[4] is not None else None

    def verified_project_for_chat(self, chat_id: str, project_store) -> dict | None:
        """Select the newest READY project belonging to this verified private chat."""
        with self.lock:
            rows = self.db.execute("SELECT project_id FROM telegram_verifications WHERE chat_id=? AND verified_at IS NOT NULL ORDER BY verified_at DESC", (chat_id,)).fetchall()
        for (project_id,) in rows:
            project = project_store.get(project_id)
            if project and project["stage"] == "READY":
                return project
        return None

    def bot_enabled(self, project_id: str) -> bool:
        with self.lock:
            row = self.db.execute("SELECT enabled FROM telegram_bot_controls WHERE project_id=?", (project_id,)).fetchone()
        return bool(row[0]) if row else True

    def set_bot_enabled(self, project_id: str, enabled: bool) -> bool:
        with self.lock:
            self.db.execute("INSERT INTO telegram_bot_controls(project_id,enabled) VALUES (?,?) ON CONFLICT(project_id) DO UPDATE SET enabled=excluded.enabled", (project_id, int(enabled)))
            self.db.commit()
        return enabled

    def status(self, project_id: str) -> dict:
        with self.lock:
            row = self._row(project_id)
        if not row:
            return {"verified": False, "pending": False, "username": None,
                    "expires_at": None, "attempts_remaining": MAX_VERIFY_ATTEMPTS}
        chat_id, digest, expires, attempts, verified_at, _, username = row
        verified = verified_at is not None
        pending = not verified and digest is not None and expires is not None and expires > time.time()
        return {"verified": verified, "pending": pending, "username": username,
                "expires_at": datetime.fromtimestamp(expires, timezone.utc).isoformat() if pending else None,
                "attempts_remaining": max(0, MAX_VERIFY_ATTEMPTS - attempts) if pending else MAX_VERIFY_ATTEMPTS}

    async def request_code(self, project_id: str, username: str) -> dict:
        username = username.strip()
        if not USERNAME_PATTERN.fullmatch(username):
            raise VerificationError("Enter a Telegram @username (for example @exampleuser), not an ID or phone number.")
        if not os.getenv("TELEGRAM_BOT_TOKEN", "").strip():
            raise VerificationError("Set TELEGRAM_BOT_TOKEN in .env first.")
        async with self.send_lock:
            chat_id = await self._resolve_username(username)
            now = time.time()
            with self.lock:
                row = self._row(project_id)
                if row and row[4] is not None:
                    raise VerificationError("Telegram is already verified for this project. Start a new project to link another account.")
                # Per-project and per-recipient limits prevent arbitrary Telegram spam.
                self.db.execute("DELETE FROM telegram_verification_sends WHERE sent_at < ?", (now - 86400,))
                recent_project = self.db.execute("SELECT COUNT(*) FROM telegram_verification_sends WHERE project_id=? AND sent_at>?",
                                                 (project_id, now - 3600)).fetchone()[0]
                recent_chat = self.db.execute("SELECT COUNT(*) FROM telegram_verification_sends WHERE chat_id=? AND sent_at>?",
                                              (chat_id, now - 3600)).fetchone()[0]
                last_chat = self.db.execute("SELECT MAX(sent_at) FROM telegram_verification_sends WHERE chat_id=?", (chat_id,)).fetchone()[0]
                if recent_project >= MAX_SENDS_PER_HOUR or recent_chat >= MAX_SENDS_PER_HOUR:
                    raise VerificationError("Verification limit reached. Try again in one hour.")
                if (row and row[5] and now - row[5] < RESEND_COOLDOWN_SECONDS) or (last_chat and now - last_chat < RESEND_COOLDOWN_SECONDS):
                    raise VerificationError("Please wait 60 seconds before requesting another code.")
            code = f"{secrets.randbelow(1_000_000):06d}"
            await send_verification_code(chat_id, code)
            with self.lock:
                self.db.execute("""INSERT INTO telegram_verifications
                    (project_id, chat_id, code_hash, expires_at, attempts, verified_at, last_sent_at, username)
                    VALUES (?, ?, ?, ?, 0, NULL, ?, ?)
                    ON CONFLICT(project_id) DO UPDATE SET chat_id=excluded.chat_id,
                    code_hash=excluded.code_hash, expires_at=excluded.expires_at,
                    attempts=0, verified_at=NULL, last_sent_at=excluded.last_sent_at,
                    username=excluded.username""",
                    (project_id, chat_id, self._digest(project_id, chat_id, code), now + CODE_TTL_SECONDS, now, username))
                self.db.execute("INSERT INTO telegram_verification_sends VALUES (?, ?, ?)", (project_id, chat_id, now))
                self.db.commit()
            return self.status(project_id)

    def verify(self, project_id: str, code: str) -> dict:
        if not re.fullmatch(r"[0-9]{6}", code):
            raise VerificationError("Enter the six-digit code from Telegram.")
        with self.lock:
            row = self._row(project_id)
            if not row:
                raise VerificationError("Request a Telegram verification code first.")
            chat_id, digest, expires, attempts, verified_at, _, _username = row
            if verified_at is not None:
                return self.status(project_id)
            if digest is None or expires is None or time.time() > expires:
                raise VerificationError("Code expired or invalidated by server restart. Request a new code.")
            if attempts >= MAX_VERIFY_ATTEMPTS:
                raise VerificationError("Too many incorrect attempts. Request a new code after the cooldown.")
            candidate = self._digest(project_id, chat_id, code)
            if not hmac.compare_digest(candidate, digest):
                attempts += 1
                self.db.execute("UPDATE telegram_verifications SET attempts=?, code_hash=? WHERE project_id=?",
                                (attempts, None if attempts >= MAX_VERIFY_ATTEMPTS else digest, project_id))
                self.db.commit()
                raise VerificationError("Incorrect verification code. Please check Telegram and try again.")
            self.db.execute("""UPDATE telegram_verifications SET verified_at=?, code_hash=NULL,
                expires_at=NULL, attempts=0 WHERE project_id=?""", (time.time(), project_id))
            self.db.commit()
            return self.status(project_id)

    def close(self):
        self.db.close()
