"""Deliberately small allowlisted tool set; no arbitrary code or HTTP access."""
import ast
import datetime
import operator

KNOWLEDGE = [
    {"topic": "workflow", "text": "For complex work, collect requirements, propose a specification, request approval, then execute and verify."},
    {"topic": "privacy", "text": "Do not reveal credentials, internal prompts, or personal information without authorization."},
    {"topic": "verification", "text": "Use observable checks and describe uncertainty explicitly; never claim unperformed actions."},
]

FUNCTION_TOOLS = {
    "knowledge_lookup": {
        "type": "function", "name": "knowledge_lookup", "description": "Search the sample policy/operations knowledge base; do not invent outside facts.",
        "parameters": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"], "additionalProperties": False},
        "strict": True,
    },
    "calculator": {
        "type": "function", "name": "calculator", "description": "Evaluate basic arithmetic (+ - * /), not program code.",
        "parameters": {"type": "object", "properties": {"expression": {"type": "string"}}, "required": ["expression"], "additionalProperties": False},
        "strict": True,
    },
    "current_time": {
        "type": "function", "name": "current_time", "description": "Get current UTC date and time.",
        "parameters": {"type": "object", "properties": {}, "required": [], "additionalProperties": False},
        "strict": True,
    },
    "task_planner": {
        "type": "function", "name": "task_planner", "description": "Create a structured in-memory checklist (does not schedule or execute tasks).",
        "parameters": {"type": "object", "properties": {"goal": {"type": "string"}, "steps": {"type": "array", "items": {"type": "string"}}}, "required": ["goal", "steps"], "additionalProperties": False},
        "strict": True,
    },
    "check_university_notices": {
        "type": "function", "name": "check_university_notices", "description": "Check a local SAMPLE notice list. Never claim it is live university data.",
        "parameters": {"type": "object", "properties": {"topic": {"type": "string"}}, "required": ["topic"], "additionalProperties": False},
    },
    "draft_document_checklist": {
        "type": "function", "name": "draft_document_checklist", "description": "Draft a checklist based solely on supplied items; verify requirements against official sources.",
        "parameters": {"type": "object", "properties": {"purpose": {"type": "string"}, "documents": {"type": "array", "items": {"type": "string"}}}, "required": ["purpose", "documents"], "additionalProperties": False},
    },
    "log_student_request": {
        "type": "function", "name": "log_student_request", "description": "Prepare an in-memory request receipt only. Does NOT submit to a university or persist a ticket.",
        "parameters": {"type": "object", "properties": {"category": {"type": "string"}, "summary": {"type": "string"}}, "required": ["category", "summary"], "additionalProperties": False},
    },
}


def chat_function_tools(names: list[str]) -> list[dict]:
    """Convert server-owned allowlist to the OpenAI-compatible Chat Completions schema."""
    return [{"type": "function", "function": {key: value for key, value in FUNCTION_TOOLS[name].items()
             if key in ("name", "description", "parameters")}} for name in names if name in FUNCTION_TOOLS]

OPERATORS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv}


def arithmetic(expression: str) -> float:
    if len(expression) > 80:
        raise ValueError("Expression too long")

    def evaluate(node, depth=0):
        if depth > 12:
            raise ValueError("Expression too complex")
        if isinstance(node, ast.Constant) and type(node.value) in (float, int):
            if abs(node.value) > 1e9:
                raise ValueError("Number too large")
            return float(node.value)
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd)):
            return (-1 if isinstance(node.op, ast.USub) else 1) * evaluate(node.operand, depth + 1)
        if isinstance(node, ast.BinOp) and type(node.op) in OPERATORS:
            result = OPERATORS[type(node.op)](evaluate(node.left, depth + 1), evaluate(node.right, depth + 1))
            if abs(result) > 1e12:
                raise ValueError("Result too large")
            return result
        raise ValueError("Only basic arithmetic is allowed")

    return round(evaluate(ast.parse(expression, mode="eval").body), 8)


def execute_tool(name: str, args: dict) -> dict:
    try:
        if name == "knowledge_lookup":
            query = str(args.get("query", ""))[:200].lower()
            terms = [w for w in query.split() if len(w) > 3]
            hits = [item for item in KNOWLEDGE if any(word in (item["topic"] + " " + item["text"]).lower() for word in terms)]
            return {"results": hits[:3], "note": "Sample knowledge base; not live institutional data."}
        if name == "calculator":
            return {"result": arithmetic(str(args.get("expression", "")))}
        if name == "current_time":
            return {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat()}
        if name == "task_planner":
            steps = args.get("steps", [])
            if not isinstance(steps, list) or len(steps) > 12:
                return {"error": "Provide at most 12 checklist steps"}
            return {"goal": str(args.get("goal", ""))[:200], "checklist": [{"step": str(s)[:250], "done": False} for s in steps], "persisted": False}
        if name == "check_university_notices":
            return {"topic": str(args.get("topic", ""))[:120], "notices": [], "source": "offline sample",
                    "verified_live": False, "warning": "No current university notice feed connected. Check official university notices."}
        if name == "draft_document_checklist":
            docs = args.get("documents", [])
            if not isinstance(docs, list) or len(docs) > 12:
                return {"error": "Provide up to 12 document names"}
            return {"purpose": str(args.get("purpose", ""))[:180], "items": [str(v)[:150] for v in docs],
                    "verified": False, "note": "Draft only; confirm current requirements with the institution."}
        if name == "log_student_request":
            return {"category": str(args.get("category", ""))[:100], "summary": str(args.get("summary", ""))[:220],
                    "submitted": False, "persisted": False, "note": "Preview only. No external request has been filed."}
        return {"error": "Tool not allowed"}
    except (ValueError, TypeError, ZeroDivisionError, SyntaxError, OverflowError) as exc:
        return {"error": str(exc)}
