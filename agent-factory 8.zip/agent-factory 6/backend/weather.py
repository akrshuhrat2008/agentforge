"""Read-only current weather from Open-Meteo; no recurring notifications."""

import httpx


class WeatherError(Exception):
    """Credential-free weather service error suitable for display."""


WEATHER_CODES = {
    0: "clear sky", 1: "mainly clear", 2: "partly cloudy", 3: "overcast",
    45: "fog", 48: "rime fog", 51: "light drizzle", 53: "drizzle", 55: "dense drizzle",
    56: "freezing drizzle", 57: "heavy freezing drizzle", 61: "light rain", 63: "rain",
    65: "heavy rain", 66: "freezing rain", 67: "heavy freezing rain", 71: "light snow",
    73: "snow", 75: "heavy snow", 77: "snow grains", 80: "rain showers",
    81: "moderate rain showers", 82: "violent rain showers", 85: "snow showers",
    86: "heavy snow showers", 95: "thunderstorm", 96: "thunderstorm with hail",
    99: "severe thunderstorm with hail",
}


async def weather_briefing(city: str) -> str:
    """Query Open-Meteo geocoding and forecast; never invent a reading."""
    try:
        async with httpx.AsyncClient(timeout=12.0) as client:
            location_response = await client.get("https://geocoding-api.open-meteo.com/v1/search", params={
                "name": city, "count": 1, "language": "en", "format": "json",
            })
            location_response.raise_for_status()
            locations = location_response.json().get("results", [])
            if not locations:
                raise WeatherError(f"No weather location found for '{city}'.")
            loc = locations[0]
            forecast_response = await client.get("https://api.open-meteo.com/v1/forecast", params={
                "latitude": loc["latitude"], "longitude": loc["longitude"],
                "current": "temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,weather_code,wind_speed_10m",
                "timezone": loc.get("timezone", "auto"), "forecast_days": 1,
            })
            forecast_response.raise_for_status()
            current = forecast_response.json()["current"]
    except httpx.HTTPStatusError as exc:
        raise WeatherError(f"Open-Meteo returned HTTP {exc.response.status_code}.") from None
    except (httpx.RequestError, ValueError, KeyError, TypeError) as exc:
        raise WeatherError(f"Weather service unavailable ({type(exc).__name__}).") from None

    name = loc.get("name", city)
    country = loc.get("country", "")
    conditions = WEATHER_CODES.get(current.get("weather_code"), "conditions unavailable")
    return (
        f"🌤️ Agent Forge weather | {name}, {country}\n"
        f"🕒 Local reading: {current.get('time', 'unknown')}\n"
        f"🌡️ {current.get('temperature_2m', '?')}°C (feels like {current.get('apparent_temperature', '?')}°C)\n"
        f"☁️ {conditions} | 💧 Humidity: {current.get('relative_humidity_2m', '?')}%\n"
        f"🌧️ Precipitation: {current.get('precipitation', '?')} mm | "
        f"💨 Wind: {current.get('wind_speed_10m', '?')} km/h\n"
        "Source: Open-Meteo forecast model (not an official weather warning)."
    )
