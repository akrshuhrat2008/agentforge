"""Gemini via Google's OpenAI-compatible Chat Completions endpoint.

API keys never leave FastAPI. Tests execute the actual built agent; the
separate model-based grader is in pipeline.py.
"""
import asyncio
import json
import os
import random
import re

from .schemas import Spec
from .tools import chat_function_tools, execute_tool

GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/openai/"


def live_mode() -> bool:
    return bool(os.getenv("GEMINI_API_KEY", "").strip())


def model_name(role: str = "fast") -> str:
    # Official Gemini model IDs. Availability still depends on account/region/quota.
    return os.getenv("MODEL_SMART" if role == "smart" else "MODEL_FAST",
                     "gemini-3.8-flash" if role == "smart" else "gemini-3.5-flash-lite")


def fallback_model(role: str = "fast") -> str:
    return os.getenv("MODEL_SMART_FALLBACK" if role == "smart" else "MODEL_FAST_FALLBACK",
                     "gemini-3.6-flash" if role == "smart" else "gemini-3.8-flash")


def parse_json(value: str) -> dict:
    cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", value.strip(), flags=re.I)
    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError:
        start, end = cleaned.find("{"), cleaned.rfind("}")
        if start < 0 or end <= start:
            raise ValueError("Model returned no JSON object")
        parsed = json.loads(cleaned[start:end + 1])
    if not isinstance(parsed, dict):
        raise ValueError("Expected a JSON object from model")
    return parsed


async def _request(messages: list[dict], role: str = "fast", tools: list[dict] | None = None):
    if not live_mode():
        raise RuntimeError("GEMINI_API_KEY is missing; live model execution is unavailable")
    from openai import AsyncOpenAI, APIConnectionError, APIStatusError, APITimeoutError, RateLimitError

    models = list(dict.fromkeys([model_name(role), fallback_model(role)]))
    last_issue = "unavailable"
    async with AsyncOpenAI(api_key=os.environ["GEMINI_API_KEY"], base_url=GEMINI_URL,
                           timeout=35, max_retries=0) as client:
        for model in models:
            for attempt in range(2):
                try:
                    kwargs = {"model": model, "messages": messages}
                    if tools:
                        kwargs["tools"] = tools
                    return await client.chat.completions.create(**kwargs)
                except (RateLimitError, APIConnectionError, APITimeoutError) as exc:
                    last_issue = ("HTTP 429: quota or rate limit" if isinstance(exc, RateLimitError)
                                  else f"connection issue ({type(exc).__name__})")
                    if attempt == 0:
                        await asyncio.sleep(1.5 + random.uniform(0, .4))
                    # After the second attempt, switch models even on a timeout or 429.
                except APIStatusError as exc:
                    denied_model = (exc.status_code in (400, 403) and "model" in str(exc).lower()
                                    and any(x in str(exc).lower() for x in ("not available", "not supported", "not found", "not accessible", "no access")))
                    if exc.status_code in (401, 403) and not denied_model:
                        raise RuntimeError("Gemini rejected your API credentials. Check GEMINI_API_KEY and model access.") from None
                    if exc.status_code == 404 or denied_model:
                        last_issue = f"model '{model}' not accessible (HTTP {exc.status_code})"
                        break
                    if exc.status_code in (429, 500, 502, 503, 504):
                        last_issue = f"HTTP {exc.status_code} ({'model overloaded' if exc.status_code == 503 else 'temporary service issue'})"
                        if attempt == 0:
                            await asyncio.sleep(1.5 + random.uniform(0, .4))
                        continue
                    # Show status and model, not raw provider errors or possible sensitive inputs.
                    raise RuntimeError(f"Gemini rejected model '{model}' (HTTP {exc.status_code}). Check model settings.") from None
    raise RuntimeError(f"Gemini could not complete the request after trying {', '.join(models)}: {last_issue}. Try again in a minute or check /health/models.")


async def complete(instructions: str, prompt: str, role: str = "fast") -> str:
    reply = await _request([{"role": "system", "content": instructions}, {"role": "user", "content": prompt}], role=role)
    content = reply.choices[0].message.content
    if not isinstance(content, str) or not content.strip():
        raise ValueError("Gemini returned no text content")
    return content.strip()


async def complete_spec(instructions: str, prompt: str) -> dict:
    last_error = None
    for attempt in range(2):
        try:
            payload = prompt if attempt == 0 else prompt + "\nYour prior response did not match the schema; return valid JSON with exactly five distinct cases."
            return Spec.model_validate(parse_json(await complete(instructions, payload, role="smart"))).model_dump()
        except (ValueError, json.JSONDecodeError) as exc:
            last_error = exc
    raise ValueError(f"Architect returned invalid structured JSON: {last_error}")


async def agent_reply(prompt: str, message: str, tools: list[str], history: list[dict] | None = None) -> tuple[str, list[dict]]:
    """Real target-agent execution, bounded to three allowlisted tool-call rounds."""
    messages = [{"role": "system", "content": prompt}]
    messages += [{"role": item["role"], "content": item["content"][:2500]} for item in (history or [])[-8:]
                 if item.get("role") in ("user", "assistant") and isinstance(item.get("content"), str)]
    messages.append({"role": "user", "content": message[:3000]})
    trace: list[dict] = []
    definitions = chat_function_tools(tools)
    for _ in range(4):
        answer = await _request(messages, role="fast", tools=definitions)
        candidate = answer.choices[0].message
        calls = candidate.tool_calls or []
        if not calls:
            return (candidate.content or "I couldn't produce a response. Please try again.", trace)
        messages.append({
            "role": "assistant",
            "content": candidate.content,
            "tool_calls": [
                call.model_dump(exclude_none=True)
                for call in calls
            ],
        })
        for call in calls:
            name = call.function.name
            try:
                args = json.loads(call.function.arguments or "{}")
                if not isinstance(args, dict):
                    args = {}
            except json.JSONDecodeError:
                args = {}
            result = execute_tool(name, args) if name in tools else {"error": "Tool not enabled for this agent"}
            trace.append({"tool": name, "arguments": args, "result": result})
            messages.append({"role": "tool", "tool_call_id": call.id, "content": json.dumps(result)})
    return ("I reached my safe tool-call limit. Please try a narrower request.", trace)


async def check_models() -> dict:
    """Non-mutating connectivity check; never return the API key."""
    if not live_mode():
        return {"connected": False, "reason": "Set GEMINI_API_KEY on the backend"}
    try:
        answer = await complete("Reply with exactly OK.", "Connectivity check", role="fast")
        return {"connected": bool(answer), "fast_model": model_name(), "smart_model": model_name("smart")}
    except Exception as exc:
        return {"connected": False, "reason": f"{type(exc).__name__}: {str(exc)[:140]}"}
