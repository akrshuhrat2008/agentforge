"""Live, single-process Telegram polling bridge for QA-approved Agent Forge agents.

Uses the same getUpdates consumer as username verification. Run one Uvicorn
worker, with no webhook or second Telegram polling application.
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import time

import httpx

from . import pipeline
from .telegram_verification import TelegramVerificationStore, VerificationError
from .weather import weather_briefing, WeatherError

logger = logging.getLogger(__name__)


class TelegramDeliveryError(Exception):
    pass


async def telegram_send(chat_id: str, text: str) -> None:
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    if not token:
        raise TelegramDeliveryError("Telegram bot token is missing.")
    # Telegram text messages are limited to 4096 characters; leave headroom.
    text = text[:3800] + ("\n…(truncated)" if len(text) > 3800 else "")
    try:
        async with httpx.AsyncClient(timeout=12.0) as client:
            response = await client.post(
                f"https://api.telegram.org/bot{token}/sendMessage",
                json={"chat_id": chat_id, "text": text},
            )
        if response.status_code != 200 or not response.json().get("ok"):
            raise TelegramDeliveryError(f"Telegram delivery failed (HTTP {response.status_code}).")
    except (httpx.RequestError, ValueError) as exc:
        if isinstance(exc, TelegramDeliveryError):
            raise
        # Telegram's request URL contains the token: never display raw exceptions.
        raise TelegramDeliveryError("Telegram delivery unavailable. Check your connection and bot access.") from None


class TelegramRuntime:
    def __init__(self, verifier: TelegramVerificationStore, projects):
        self.verifier = verifier
        self.projects = projects
        self.task: asyncio.Task | None = None
        self.pending: set[asyncio.Task] = set()
        self.chat_locks: dict[str, asyncio.Lock] = {}
        self.last_error: str | None = None
        self.last_sent: dict[str, float] = {}
        self.verifier.on_message = self.enqueue

    def active(self) -> bool:
        return self.task is not None and not self.task.done()

    def start(self):
        if os.getenv("TELEGRAM_BOT_TOKEN", "").strip() and not self.active():
            self.task = asyncio.create_task(self._poll())

    async def stop(self):
        if self.task:
            self.task.cancel()
            await asyncio.gather(self.task, return_exceptions=True)
            self.task = None
        for task in list(self.pending):
            task.cancel()
        if self.pending:
            await asyncio.gather(*self.pending, return_exceptions=True)
        self.pending.clear()

    async def _poll(self):
        while True:
            try:
                await self.verifier._refresh_known_users()
                self.last_error = None
                await asyncio.sleep(0.2)
            except asyncio.CancelledError:
                raise
            except VerificationError as exc:
                if self.last_error != str(exc):
                    logger.warning("Telegram polling paused: %s", exc)
                self.last_error = str(exc)
                await asyncio.sleep(5)
            except Exception:
                logger.exception("Unexpected Telegram bridge failure")
                self.last_error = "Telegram polling encountered an unexpected error."
                await asyncio.sleep(5)

    async def enqueue(self, message: dict):
        """Non-blocking dispatch so Gemini latency cannot stall verification."""
        if len(self.pending) >= 12:
            logger.warning("Telegram bot busy: dropping update to protect capacity")
            return
        task = asyncio.create_task(self._handle_ordered(message))
        self.pending.add(task)
        task.add_done_callback(self.pending.discard)

    async def _handle_ordered(self, message: dict):
        chat_id = str(message["chat"]["id"])
        async with self.chat_locks.setdefault(chat_id, asyncio.Lock()):
            try:
                await self.handle_message(message)
            except asyncio.CancelledError:
                raise
            except TelegramDeliveryError as exc:
                logger.warning("Could not deliver Telegram reply: %s", exc)
            except Exception:
                logger.exception("Telegram handler failed")

    async def handle_message(self, message: dict):
        chat_id = str(message["chat"]["id"])
        raw_text = message.get("text", "").strip()
        if not raw_text:
            return
        command = raw_text.split()[0].split("@", 1)[0].lower()
        if command == "/start":
            await telegram_send(chat_id, "👋 Agent Forge here. Verify your @username on the Agent Forge website. After your agent passes QA, send /weather or any message here. Use /pause and /resume to control replies.")
            return
        project = self.verifier.verified_project_for_chat(chat_id, self.projects)
        if not project:
            # Avoid serving models or data to unverified Telegram users.
            return
        project_id = project["project_id"]
        if command == "/pause":
            self.verifier.set_bot_enabled(project_id, False)
            await telegram_send(chat_id, "⏸ Agent Forge paused. Send /resume to reactivate replies.")
            return
        if command == "/resume":
            self.verifier.set_bot_enabled(project_id, True)
            await telegram_send(chat_id, "✅ Agent Forge resumed. Send a message or /weather.")
            return
        if command == "/status":
            enabled = self.verifier.bot_enabled(project_id)
            await telegram_send(chat_id, f"Agent Forge: {'active ✅' if enabled else 'paused ⏸'} | {project['agent_artifact']['name']}")
            return
        if not self.verifier.bot_enabled(project_id):
            return  # Complete silence while paused, except control commands.

        # Weather is a live API query, never an LLM guess or simulation.
        weather_match = re.fullmatch(r"(?:/weather|weather)(?:\s+(?:in\s+)?([\w\s,.'-]{2,70}))?\s*", raw_text, re.I)
        try:
            if weather_match:
                city = (weather_match.group(1) or "Debrecen").strip()
                answer = await weather_briefing(city)
            else:
                result = await pipeline.sandbox_chat(self.projects, project, raw_text[:3000])
                answer = result["reply"]
        except WeatherError as exc:
            answer = f"Couldn't fetch live weather: {exc}. Try /weather again shortly."
        except Exception:
            logger.exception("Agent could not handle Telegram message")
            answer = "The AI service is temporarily unavailable. Please try again in a minute."
        await telegram_send(chat_id, answer)

    async def send_test(self, project_id: str):
        chat_id = self.verifier.verified_chat_id(project_id)
        if not chat_id:
            raise ValueError("Verify Telegram first.")
        project = self.projects.get(project_id)
        if not project or project["stage"] != "READY":
            raise ValueError("The agent must pass QA before sending messages.")
        now = time.monotonic()
        if now - self.last_sent.get(project_id, -100) < 10:
            raise ValueError("Wait 10 seconds before another test message.")
        await telegram_send(chat_id, f"✅ {project['agent_artifact']['name']} is connected to Agent Forge!\n\nSend /weather for live Debrecen weather, or say hello. /pause and /resume control automatic replies.")
        self.last_sent[project_id] = now

