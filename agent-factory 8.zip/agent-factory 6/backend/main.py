"""Run from the project root: uvicorn backend.main:app --reload"""
import asyncio
from contextlib import asynccontextmanager
import io
import json
import os
from pathlib import Path
import zipfile

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, status
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from . import ai, pipeline
from .schemas import ApprovalInput, ChatInput, MessageInput, PipelineInput, TelegramUsernameInput, TelegramCodeInput, TelegramControlInput
from .store import ProjectStore
from .telegram_verification import TelegramVerificationStore, VerificationError, telegram_bot_url
from .telegram_runtime import TelegramRuntime, TelegramDeliveryError
from .weather import WeatherError, weather_briefing

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")
DB_PATH = os.getenv("AGENT_FACTORY_DB", str(ROOT / ".data" / "projects.sqlite"))
store = ProjectStore(DB_PATH)
telegram_verification = TelegramVerificationStore(DB_PATH)
telegram_runtime = TelegramRuntime(telegram_verification, store)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    telegram_runtime.start()
    try:
        yield
    finally:
        await telegram_runtime.stop()


app = FastAPI(title="Agent Forge", version="4.0.0", description="QA-approved Telegram agents with live private-chat replies", lifespan=lifespan)
app.mount("/assets", StaticFiles(directory=str(ROOT / "frontend")), name="assets")
_running: dict[str, asyncio.Task] = {}


def project_or_404(project_id: str) -> dict:
    state = store.get(project_id)
    if not state:
        raise HTTPException(404, "Project not found")
    return state


def require_verified(project_id: str):
    if not telegram_verification.verified_chat_id(project_id):
        raise HTTPException(403, "Verify your Telegram account before creating or running an agent.")


@app.get("/")
async def index():
    return FileResponse(ROOT / "frontend" / "index.html")


@app.get("/health")
async def health():
    return {"ok": True, "mode": "live" if ai.live_mode() else "demo", "provider": "Gemini via OpenAI-compatible SDK"}


@app.get("/health/models")
async def models_health():
    return await ai.check_models()


@app.get("/api/config")
async def config():
    return {"mode": "live" if ai.live_mode() else "demo", "model": ai.model_name() if ai.live_mode() else None,
            "model_smart": ai.model_name("smart") if ai.live_mode() else None,
            "max_fix_cycles": pipeline.MAX_FIX_CYCLES, "test_cases": 5,
            "channels": {"telegram": bool(os.getenv("TELEGRAM_BOT_TOKEN", "").strip()), "weather": True},
            "telegram_live": telegram_runtime.active(),
            "telegram_bot_url": telegram_bot_url()}


@app.get("/health/telegram")
async def telegram_health():
    return {"running": telegram_runtime.active(), "error": telegram_runtime.last_error}


@app.get("/api/weather")
async def current_weather(city: str = "Debrecen"):
    if not 2 <= len(city) <= 80:
        raise HTTPException(422, "City must contain 2–80 characters.")
    try:
        return {"city": city, "message": await weather_briefing(city), "source": "Open-Meteo"}
    except WeatherError as exc:
        raise HTTPException(502, str(exc)) from exc


@app.get("/projects/{project_id}/telegram/status")
async def telegram_status(project_id: str):
    project_or_404(project_id)
    return {"telegram": {**telegram_verification.status(project_id),
                         "enabled": telegram_verification.bot_enabled(project_id),
                         "listener_running": telegram_runtime.active(),
                         "listener_error": telegram_runtime.last_error}, "bot_url": telegram_bot_url()}


@app.post("/projects/{project_id}/telegram/control")
async def telegram_control(project_id: str, request: TelegramControlInput):
    project_or_404(project_id)
    require_verified(project_id)
    return {"enabled": telegram_verification.set_bot_enabled(project_id, request.enabled)}


@app.post("/projects/{project_id}/telegram/test")
async def telegram_test(project_id: str):
    project_or_404(project_id)
    require_verified(project_id)
    try:
        await telegram_runtime.send_test(project_id)
        return {"sent": True}
    except ValueError as exc:
        raise HTTPException(409, str(exc)) from exc
    except TelegramDeliveryError as exc:
        raise HTTPException(502, str(exc)) from exc


@app.post("/projects/{project_id}/telegram/request-code")
async def telegram_request_code(project_id: str, request: TelegramUsernameInput):
    project_or_404(project_id)
    try:
        return {"telegram": await telegram_verification.request_code(project_id, request.username)}
    except VerificationError as exc:
        raise HTTPException(429 if "wait" in str(exc).lower() or "limit" in str(exc).lower() else 409, str(exc)) from exc


@app.post("/projects/{project_id}/telegram/verify")
async def telegram_verify(project_id: str, request: TelegramCodeInput):
    project_or_404(project_id)
    try:
        return {"telegram": telegram_verification.verify(project_id, request.code)}
    except VerificationError as exc:
        raise HTTPException(409, str(exc)) from exc


@app.get("/api/projects")
async def list_projects():
    return {"projects": store.recent()}


@app.post("/api/projects", status_code=201)
async def create_project():
    return store.create()


@app.get("/projects/{project_id}/state")
async def get_state(project_id: str):
    return project_or_404(project_id)


@app.post("/projects/{project_id}/message")
async def message(project_id: str, request: MessageInput):
    state = project_or_404(project_id)
    require_verified(project_id)
    try:
        next_state, reply = await pipeline.handle_message(store, state, request.message)
        return {"reply": reply, "state": next_state}
    except ValueError as exc:
        raise HTTPException(409, str(exc)) from exc
    except Exception as exc:
        raise HTTPException(502, f"Could not generate the specification: {type(exc).__name__}: {str(exc)[:170]}") from exc


@app.post("/projects/{project_id}/approve")
async def approve(project_id: str, request: ApprovalInput):
    state = project_or_404(project_id)
    require_verified(project_id)
    try:
        return pipeline.approve_spec(store, state, request.spec_version)
    except ValueError as exc:
        raise HTTPException(409, str(exc)) from exc


@app.post("/projects/{project_id}/run-pipeline", status_code=status.HTTP_202_ACCEPTED)
async def run_pipeline(project_id: str, request: PipelineInput | None = None):
    state = project_or_404(project_id)
    require_verified(project_id)
    if state["stage"] != "BUILDING" or state["agent_artifact"] is not None:
        raise HTTPException(409, "Approve a spec before running the pipeline; it can run once per project.")
    if project_id in _running and not _running[project_id].done():
        raise HTTPException(409, "Pipeline already running")

    state["pipeline_started"] = True
    store.save(state)
    if request and request.wait:
        await pipeline.run_pipeline(store, project_id, request.inject_demo_fault)
        return JSONResponse(status_code=200, content=store.get(project_id))

    async def execute():
        try:
            await pipeline.run_pipeline(store, project_id, request.inject_demo_fault if request else False)
        finally:
            _running.pop(project_id, None)

    _running[project_id] = asyncio.create_task(execute())
    return {"status": "started", "project_id": project_id}


@app.post("/projects/{project_id}/agent/chat")
async def agent_chat(project_id: str, request: ChatInput):
    state = project_or_404(project_id)
    require_verified(project_id)
    try:
        return await pipeline.sandbox_chat(store, state, request.message.strip())
    except ValueError as exc:
        raise HTTPException(409, str(exc)) from exc
    except Exception as exc:
        raise HTTPException(502, f"Agent request failed: {type(exc).__name__}: {str(exc)[:170]}") from exc


@app.get("/projects/{project_id}/export")
async def export_project(project_id: str):
    state = project_or_404(project_id)
    require_verified(project_id)
    if state["stage"] != "READY":
        raise HTTPException(409, "Export is available after successful QA.")
    memory = io.BytesIO()
    payloads = {
        "approved_spec.json": state["approved_spec"],
        "working_spec.json": state["working_spec"],
        "five_test_cases.json": state["approved_spec"]["test_cases"],
        "agent_artifact.json": state["agent_artifact"],
        "qa_reports.json": state["qa_reports"],
        "evidence_report.json": state["evidence_report"],
        "events.json": state["events"],
    }
    with zipfile.ZipFile(memory, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for name, value in payloads.items():
            z.writestr(name, json.dumps(value, indent=2, ensure_ascii=False))
        z.writestr("README.txt", "Agent Forge evidence bundle: five_test_cases.json, before/after QA reports, working vs. approved TZ, safe tool configuration.\nIf verified_by_real_models=false, results are an explicitly offline simulation, NOT independent AI test evidence.\nNo arbitrary code is generated or executed.\n")
    memory.seek(0)
    return StreamingResponse(memory, media_type="application/zip",
                             headers={"Content-Disposition": f'attachment; filename="agent-{project_id}.zip"'})
