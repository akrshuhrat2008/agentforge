from typing import Literal

from pydantic import BaseModel, Field, model_validator


Stage = Literal[
    "INTERVIEWING", "AWAITING_SPEC_APPROVAL", "BUILDING",
    "TESTING", "FIXING", "READY", "FAILED",
]


class TelegramUsernameInput(BaseModel):
    username: str = Field(pattern=r"^@[A-Za-z0-9_]{5,32}$")


class TelegramCodeInput(BaseModel):
    code: str = Field(pattern=r"^[0-9]{6}$")


class TelegramControlInput(BaseModel):
    enabled: bool


class MessageInput(BaseModel):
    message: str = Field(min_length=1, max_length=5000)


class ApprovalInput(BaseModel):
    spec_version: int = Field(ge=1)


class PipelineInput(BaseModel):
    inject_demo_fault: bool = False
    wait: bool = False


class ChatInput(BaseModel):
    message: str = Field(min_length=1, max_length=3000)


class Spec(BaseModel):
    name: str = Field(min_length=3, max_length=90)
    role: str = Field(default="Purpose-built assistant", min_length=3, max_length=250)
    tone: str = Field(default="Clear, concise, and careful", min_length=3, max_length=250)
    mission: str = Field(min_length=10, max_length=1500)
    audience: str = Field(min_length=2, max_length=300)
    capabilities: list[str] = Field(min_length=1, max_length=7)
    rules: list[str] = Field(min_length=1, max_length=8)
    acceptance_criteria: list[str] = Field(min_length=2, max_length=8)
    tools: list[Literal["knowledge_lookup", "calculator", "current_time", "task_planner", "check_university_notices", "draft_document_checklist", "log_student_request"]] = Field(default_factory=list)
    test_cases: list["TestCase"] = Field(min_length=5, max_length=5)

    @model_validator(mode="after")
    def five_unique_cases(self):
        if [case.id for case in self.test_cases] != ["F1", "F2", "A1", "A2", "A3"]:
            raise ValueError("Cases must have IDs F1, F2, A1, A2, A3 in order")
        if [case.kind for case in self.test_cases] != ["functional"] * 2 + ["adversarial"] * 3:
            raise ValueError("Exactly 2 functional and 3 adversarial cases required")
        return self


class TestCase(BaseModel):
    id: str = Field(min_length=2, max_length=30)
    name: str = Field(min_length=3, max_length=120)
    input: str = Field(min_length=5, max_length=1200)
    expected_behavior: str = Field(min_length=8, max_length=800)
    kind: Literal["functional", "adversarial"]


class AgentArtifact(BaseModel):
    name: str
    description: str
    system_prompt: str
    allowed_tools: list[str]
    constraints: list[str]
    tools: list[str]
    model: str
    spec_version: int
    build_version: int


class Check(BaseModel):
    label: str
    passed: bool
    detail: str


class QAReport(BaseModel):
    cycle: int
    passed: bool
    checks: list[Check]
    fixes: list[str]
    mode: str
    score: str
    results: list["TestResult"]


class TestResult(BaseModel):
    case_id: str
    name: str
    kind: Literal["functional", "adversarial"]
    input: str
    expected_behavior: str
    actual_output: str
    passed: bool
    failure_reason: str
    tool_trace: list[dict] = Field(default_factory=list)
