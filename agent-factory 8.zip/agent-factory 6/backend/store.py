"""Small, transparent SQLite state store for hackathon use."""
import copy
import datetime
import json
import os
import sqlite3
import threading
import uuid


class ProjectStore:
    def __init__(self, path: str):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.execute("CREATE TABLE IF NOT EXISTS projects (id TEXT PRIMARY KEY, state TEXT NOT NULL)")
        self.db.commit()
        self.lock = threading.RLock()

    def create(self) -> dict:
        item = {
            "project_id": uuid.uuid4().hex[:12], "stage": "INTERVIEWING", "idea": "",
            "conversation": [], "spec_version": 0, "draft_spec": None, "approved_spec": None,
            "spec_history": [], "working_spec": None, "agent_artifact": None,
            "qa_reports": [], "events": [], "agent_history": [], "error": None,
            "fix_cycles": 0, "pipeline_started": False, "mode": "live" if os.getenv("GEMINI_API_KEY") else "demo",
            "repair_log": [], "evidence_report": None, "test_progress": None, "interview_questions": 0,
        }
        self.event(item, "COMMUNICATOR", "Project started. Tell us what your agent should do.")
        self.save(item)
        return item

    @staticmethod
    def event(state: dict, actor: str, message: str):
        state["events"].append({"actor": actor, "message": message, "at": datetime.datetime.now(datetime.timezone.utc).isoformat()})
        state["events"] = state["events"][-90:]

    def get(self, project_id: str) -> dict | None:
        with self.lock:
            row = self.db.execute("SELECT state FROM projects WHERE id=?", (project_id,)).fetchone()
            return json.loads(row[0]) if row else None

    def save(self, state: dict):
        with self.lock:
            self.db.execute("INSERT OR REPLACE INTO projects (id, state) VALUES (?, ?)", (state["project_id"], json.dumps(state)))
            self.db.commit()
        return copy.deepcopy(state)

    def recent(self) -> list[dict]:
        with self.lock:
            rows = self.db.execute("SELECT state FROM projects ORDER BY rowid DESC LIMIT 12").fetchall()
        return [{"project_id": obj["project_id"], "stage": obj["stage"], "name": (obj.get("draft_spec") or {}).get("name", "Untitled project")}
                for obj in (json.loads(row[0]) for row in rows)]
