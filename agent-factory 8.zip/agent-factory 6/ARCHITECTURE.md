# Agent Forge v6 — Architecture

Agent Forge creates purpose-built agents from human-reviewed specifications and tests their **real outputs** before release. Telegram verifies recipient identity before access to the workshop.

```mermaid
flowchart TD
  V["Telegram @username → /start lookup → code"] --> C["Communicator: idea"]
  C --> A["Architect: spec + five tests"]
  A --> H{"Human approves?"}
  H -->|Revise| A
  H -->|Approve| B["Builder: safe agent config"]
  B --> T["Tester: execute and grade all five cases"]
  T -->|Passed| R["READY: sandbox and export"]
  T -->|Failed, repairs remain| F["Architect: repair working spec"]
  F --> B
  T -->|Repair limit reached| X["FAILED: evidence available in state"]
```

## Telegram verification

- The site requests an `@username` and passes it to FastAPI, not directly to Telegram's sendMessage API.
- The user must first send `/start` to the locally configured bot. The backend reads Telegram `getUpdates`, accepts only a **recent `/start` in a private chat** whose sender and chat identity match, and caches the username → numeric chat ID association.
- The code is sent through the Telegram Bot API using the **resolved numeric chat ID**. A six-digit code is stored as an HMAC digest, bound to the project and chat ID, expires after ten minutes, has five guesses, and is rate-limited.
- Only successful code confirmation marks that project's Telegram recipient verified. API routes for agent creation, pipeline execution, sandbox chat, and export call `require_verified` server-side; UI visibility alone is not an authorization check.
- Existing v4 databases are migrated by adding the optional username column; prior verified numeric chat identities continue working.
- A single serialized `getUpdates` reader shares the update stream between verification and the Telegram runtime; concurrent webhook/polling consumers conflict.
- The runtime accepts private messages only from a Telegram chat associated with a previously verified READY project. The most recently verified READY project for a chat is selected.
- `/weather` retrieves live Open-Meteo data, general prompts execute `pipeline.sandbox_chat` on the QA-approved artifact, and `/pause`/`/resume` set a SQLite-persisted per-project flag. Manual real `sendMessage` test is available after QA.

## QA invariants

- Human approval is version-checked. The approved specification and five test cases are immutable during repair.
- Five cases are always `F1`, `F2`, `A1`, `A2`, `A3` (two functional plus three adversarial).
- Tester executes the generated agent against each case; an independent Gemini grader evaluates outputs with deterministic safety checks.
- All cases are rerun after repairs; at most two repairs. Offline responses are explicitly marked as simulations, not externally verified evidence.
- Tools are server-owned and allowlisted; no arbitrary shell, bookings or real University of Debrecen administrative submissions.
- Gemini uses documented primary/fallback models. Temporary HTTP 429/5xx, timeout and connection errors trigger bounded retries and a fallback model. Raw error bodies and API credentials are not returned to the browser.

## Persistence and deployment limitations

SQLite stores projects, verification challenges, Telegram identity associations, incoming-update offset, and pause state. No `.env`, credentials or database is included in the downloadable project ZIP. Run on `127.0.0.1`; this MVP does not implement public multi-user auth or centralized session ownership.

`backend/weather.py` provides read-only Open-Meteo weather by city. The previous scheduling, WhatsApp and Automation Control Center backend/UI remain removed. **Verifying a chat is not enough to activate replies**: the project must reach READY and the local FastAPI process with its polling loop must stay running. A cloud-hosted worker and persistent delivery queue are future work.
