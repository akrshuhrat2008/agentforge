// Dev wrapper that accepts the managed preview's Vite-style launch flags.
import { spawn } from 'node:child_process';

const args = process.argv.slice(2);
const value = flag => {
  const index = args.indexOf(flag);
  return index === -1 ? null : args[index + 1];
};
const port = value('--port') || process.env.PORT || '3000';
const host = value('--host') || '127.0.0.1';
const processHandle = spawn('python', ['-m', 'uvicorn', 'backend.main:app', '--host', host, '--port', port], { stdio: 'inherit' });
const shutdown = signal => { if (processHandle.exitCode === null) processHandle.kill(signal); };
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
processHandle.on('exit', code => process.exit(code || 0));
